@extends('layouts.website')

@section('content')
<h1>Product Page</h1>
@endsection