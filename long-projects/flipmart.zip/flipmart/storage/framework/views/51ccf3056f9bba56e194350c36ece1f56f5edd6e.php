

<?php $__env->startSection('content'); ?>
<h1>Product Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flipmart\resources\views/website/product.blade.php ENDPATH**/ ?>