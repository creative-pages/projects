<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
	<strong><?php echo e(session('success')); ?></strong>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\flipmart\resources\views/includes/message.blade.php ENDPATH**/ ?>