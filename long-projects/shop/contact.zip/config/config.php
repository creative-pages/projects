<?php 

define("DB_HOST", "sql313.epizy.com");
define("DB_USER", "epiz_25864218");
define("DB_PASS", "PtaFdXDEscc");
define("DB_NAME", "epiz_25864218_web_room");

?>