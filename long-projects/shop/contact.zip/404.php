<?php include "inc/header.php"; ?>
<div style="text-align: center; padding: 50px 0px;">
	<h2 style="font-size: 70px;">404</h2>
	<h4 style="font-size: 50px;">Page Not Found!</h4>
</div>
<?php include "inc/footer.php"; ?>