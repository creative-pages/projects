<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>
<main>
	<div class="container-fluid pt-3">

		<a class="btn btn-info btn-sm" href="message.php"><i class="fas fa-sync-alt"></i></a>
		<a class="btn btn-info btn-sm" href="message.php">Inbox <span class="badge badge-light"><?= isset($message_inbox_count) ? $message_inbox_count : ''; ?></span></a>
		<a class="btn btn-primary btn-sm" href="message.php?seen">Seenbox</a>
		<a class="btn btn-success btn-sm" href="message.php?sent">Sent</a>
		<a class="btn btn-info btn-sm" href="message.php?compose">Compose New</a>
		<div class="bg-light mt-2">
			<div class="row">
				<div class="col-sm-6 offset-sm-3">
					<table class="table table-bordered table-striped">
	        	<tbody>
	        		<?php 
	        		if (isset($_GET['message_id'])) {
	        			$id = $_GET['message_id'];
	        			$view_message = $contact->viewMessage($id);
						if ($view_message) {
							$single_message = mysqli_fetch_assoc($view_message);
						}
	        		}
	        		
					?>
					<tr>
	        			<td>Date</td>
	        			<td><?= $fm->dateFormat($single_message['date_time']); ?></td>
	        		</tr>
	        		<tr>
	        			<td>Name</td>
	        			<td><?= $single_message['first_name'] . ' ' . $single_message['last_name']; ?></td>
	        		</tr>
	        		<tr>
	        			<td>Email</td>
	        			<td><?= $single_message['email']; ?></td>
	        		</tr>
	        		<tr>
	        			<td>Phone</td>
	        			<td><?= $single_message['phone']; ?></td>
	        		</tr>
	        		<tr>
	        			<td>Subject</td>
	        			<td><?= $single_message['subject']; ?></td>
	        		</tr>
	        		<tr>
	        			<td>Message</td>
	        			<td><?= $single_message['description']; ?></td>
	        		</tr>
	        	</tbody>
	        </table>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/footer.php"; ?>