<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php 

if (isset($_GET['delete_id'])) {
	$id = base64_decode($_GET['delete_id']);
	$delete_result = $position->deletePosition($id);
	if ($delete_result) {
		header("Location: manage_position.php");
	}
}

?>
<main class="bg-light">
	<div class="container-fluid pt-3">
		<div class="card mb-4">
			<div class="card-header">
				<span>
				Manage Position
				</span>
				<span class="float-right">
					<a href="add_position.php" class="btn btn-primary btn-sm">Add Position</a>
				</span>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>Serial No.</th>
								<th>Position</th>
								<th>Annual Leave</th>
								<th>Casual Leave</th>
								<th>Madical Leave</th>
								<th>Maternity Leave</th>
								<th>Festival Leave</th>
								<th>Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
					<?php 
						if ($all_position) {
							$sl = 1;
							while ($positions = $all_position->fetch_assoc()) {
							?>
							<tr>
								<td><?= $sl; ?></td>
								<td><?= $positions['pos']; ?></td>
								<td><?= $positions['annual_leave']; ?></td>
								<td><?= $positions['casual_leave']; ?></td>
								<td><?= $positions['medical_leave']; ?></td>
								<td><?= $positions['maternity_leave']; ?></td>
								<td><?= $positions['festival_leave']; ?></td>
								<td><?= $fm->dateFormat($positions['create_time']); ?></td>
								<td>
									<a class="btn btn-warning btn-sm" href="update_position.php?edit_position=<?= base64_encode($positions['id']); ?>">Edit</a>
									<a class="btn btn-danger btn-sm" href="manage_position.php?delete_id=<?= base64_encode($positions['id']); ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
								</td>
							</tr>
							<?php
							$sl++;
							}
						}
					?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>

<?php require_once "inc/admin_footer.php"; ?>