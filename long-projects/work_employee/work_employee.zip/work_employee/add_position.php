<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>

<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_position'])) {
	$add_pos = $position->insertPosition($_POST);
}

?>
<main>
	<div class="container-fluid pt-3">
		<br>
		<br>
		<div class="row">
			<div class="col-sm-6 offset-sm-3">
				<div class="card card-1">
					<div class="card-heading"></div>
					<div class="card-body">
						<h2 class="text-center text-muted">Add Position</h2>
						<hr>
						<form action="<?= $_SERVER["PHP_SELF"]; ?>" method="POST">
							<div class="form-group row mt-3">
							    <label for="pos" class="col-sm-3 col-form-label">Position</label>
							    <div class="col-sm-9">
							      <input type="text" class="form-control" placeholder="Enter position name" id="pos" name="pos" required="">
							    </div>
							</div>
							<div class="form-group row mt-3">
							    <label for="annual_leave" class="col-sm-3 col-form-label">Annual Leave</label>
							    <div class="col-sm-9">
							      <input type="number" class="form-control" placeholder="Enter Annual Leave" id="annual_leave" min="0" name="annual_leave" required="">
							    </div>
							</div>
							<div class="form-group row mt-3">
							    <label for="casual_leave" class="col-sm-3 col-form-label">Casual Leave</label>
							    <div class="col-sm-9">
							      <input type="number" class="form-control" placeholder="Enter Casual Leave" id="casual_leave" min="0" name="casual_leave" required="">
							    </div>
							</div>
							<div class="form-group row mt-3">
							    <label for="medical_leave" class="col-sm-3 col-form-label">Medical Leave</label>
							    <div class="col-sm-9">
							      <input type="number" class="form-control" placeholder="Enter Medical Leave" id="medical_leave" min="0" name="medical_leave" required="">
							    </div>
							</div>
							<div class="form-group row mt-3">
							    <label for="maternity_leave" class="col-sm-3 col-form-label">Maternity Leave</label>
							    <div class="col-sm-9">
							      <input type="number" class="form-control" placeholder="Enter Maternity Leave" id="maternity_leave" min="0" name="maternity_leave" required="">
							    </div>
							</div>
							<div class="form-group row mt-3">
							    <label for="festival_leave" class="col-sm-3 col-form-label">Festival Leave</label>
							    <div class="col-sm-9">
							      <input type="number" class="form-control" placeholder="Enter Festival Leave" id="festival_leave" min="0" name="festival_leave" required="">
							    </div>
							</div>
							<div class="my-3 text-right">
								<input class="btn btn-primary btn-sm" type="submit" name="add_position" value="Submit">
							</div>
						</form>
						<?php echo isset($add_pos) ? $add_pos : ''; ?>
					</div>
				</div>
			</div>
		</div>
		<br>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>