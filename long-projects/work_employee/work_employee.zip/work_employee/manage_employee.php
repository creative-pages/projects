<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php
if (isset($_GET['user_delete'])) {
	$id = base64_decode($_GET['user_delete']);
	$photo = $_GET['user_photo'];
	$delete_result = $user->deleteUser($id, $photo);
	if ($delete_result) {
		header("Location: manage_employee.php");
	}
}
?>
<main>
	<div class="container-fluid pt-3">
		<div class="card mb-4">
			<div class="card-header">
				<span>All Employee List: </span>
				<span>
					<a class="btn btn-primary btn-sm" href="add_employee.php">Add Employee</a>
				</span>
				<span class="float-right text-muted">Total Employee: <?= isset($total_users) ? $total_users : '0'; ?></span>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>EM-ID</th>
								<th>Name</th>
								<th>Email</th>
								<th>Phone</th>
								<th>Department</th>
								<th>Position</th>
								<th>Joined</th>
								<th>Photo</th>
								<th>Attendance</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$all_users = $user->allUsers();
								if ($all_users) {
							while ($all_user = $all_users->fetch_assoc()) {
							?>
							<tr>
								<td><?= $all_user['employee_id']; ?></td>
								<td><?= $all_user['first_name'] . ' ' . $all_user['last_name']; ?></td>
								<td><?= $all_user['email']; ?></td>
								<td><?= $all_user['phone']; ?></td>
								<td><?= $all_user['dept']; ?></td>
								<td><?= $all_user['pos']; ?></td>
								<td><?= $fm->dateFormat($all_user['hire_date']); ?></td>
								<td style="padding: 6px;">
									<img width="80" height="50" src="uploadFiles/<?= $all_user['photo']; ?>" alt="">
								</td>
								<td>
									<a href="attendance.php?employee_id=<?= $all_user['employee_id']; ?>&month=<?= date("Y-m"); ?>&id=<?= base64_encode($all_user['id']); ?>" class="btn btn-info btn-sm">View</a>
								</td>
								<td>
									<a class="btn btn-warning btn-sm" href="update_employee.php?edit_user=<?= base64_encode($all_user['id']); ?>">Edit</a>
									<a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete?')" href="manage_employee.php?user_delete=<?= base64_encode($all_user['id']); ?>&user_photo=<?= $all_user['photo']; ?>">Delete</a>
								</td>
							</tr>
							<?php
							}
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>