<?php require_once "inc/header.php"; ?>
<?php 

// update_profile
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $update_profile = $user->updateProfile($_POST);
}

// update_profile photo
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_photo'])) {
    $update_profile_photo = $user->updateUserPhoto($_POST);
}

?>
<?php require_once "inc/sidebar.php"; ?>
<main class="bg-light">
    <div class="container-fluid pt-3">
        <div class="row">
           <div class="col-sm-3">
               <?php 
                    if ($user_info_result['photo'] !== '') {
                    ?> 
                    <img style="width: 300px; height: 250px;" src="uploadFiles/<?= $user_info_result['photo']; ?>" class="img-fluid img-thumbnail mr-3" alt="...">
                    <?php
                    } else {
                    ?>
                    <i style="font-size: 150px!important;" class="fas fa-user fa-fw text-muted"></i>
                    <?php
                    }
                ?>
                <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="old_file" value="<?= isset($user_info_result['photo']) ? $user_info_result['photo'] : ''; ?>">
                    <input type="hidden" name="id" value="<?= isset($user_info_result['id']) ? $user_info_result['id'] : ''; ?>">
                    <input type="file" name="photo" class="form-control mt-2" required="">
                    <input type="submit" name="update_photo" class="btn btn-primary btn-sm mt-2 float-right" value="Update Photo">
                </form>
                <?php echo isset($update_profile_photo) ? $update_profile_photo : ''; ?>
           </div>
            <div class="col-sm-6">
                <div class="card card-1">
                    <div class="card-heading"></div>
                    <div class="card-body">
                        <?php echo isset($update_profile) ? $update_profile : ''; ?>
                        <h2 class="text-center text-muted">Update Profile</h2>
                        <hr>
                        <form action="" method="POST" enctype="multipart/form-data">
                            
                            <div class="form-group mb-0">
                                <input type="hidden" name="id" value="<?= isset($user_info_result['id']) ? $user_info_result['id'] : ''; ?>">
                                <input class="form-control mt-3" type="text" placeholder="Employee ID" name="employee_id" value="<?= isset($user_info_result['employee_id']) ? $user_info_result['employee_id'] : ''; ?>" required="required" readonly="">
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <input class="form-control" type="text" placeholder="First Name" value="<?= isset($user_info_result['first_name']) ? $user_info_result['first_name'] : ''; ?>" name="first_name" required="required">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <input class="form-control" type="text" placeholder="Last Name" value="<?= isset($user_info_result['last_name']) ? $user_info_result['last_name'] : ''; ?>" name="last_name" required="required">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group mb-0 mt-3">
                                <input class="form-control mt-3" type="email" placeholder="Email" name="email" value="<?= isset($user_info_result['email']) ? $user_info_result['email'] : ''; ?>" required="required">
                                <?php echo isset($user->email) ? $user->email : ''; ?>
                            </div>
                            <div class="form-group mb-0 mt-3">
                                 <input class="form-control mt-3" type="text" placeholder="Employee ID" name="dept" value="<?= isset($user_info_result['dept']) ? $user_info_result['dept'] : ''; ?>" required="required" readonly="">
                            </div>
                            <div class="form-group mb-0 mt-3">
                                <input class="form-control mt-3" type="text" placeholder="Employee ID" name="pos" value="<?= isset($user_info_result['pos']) ? $user_info_result['pos'] : ''; ?>" required="required" readonly="">
                            </div>
                            <div class="form-group mb-0 mt-3">
                                <input class="form-control" type="number" min="0" placeholder="Salary" value="<?= isset($user_info_result['salary']) ? $user_info_result['salary'] : ''; ?>" name="salary" required="" readonly="">
                            </div>
                            <div class="form-group mb-0 mt-3">
                                <label for="hire_date">Date of Hire</label>
                                <input class="form-control" type="date" placeholder="BIRTHDATE" value="<?= isset($user_info_result['hire_date']) ? $user_info_result['hire_date'] : ''; ?>" id="hire_date" name="hire_date" required="required" readonly="">
                            </div>
                            <hr>
                            <div class="form-row mt-3">
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label for="birthday">BIRTHDATE</label>
                                        <input class="form-control" type="date" placeholder="BIRTHDATE" value="<?= isset($user_info_result['birthday']) ? $user_info_result['birthday'] : ''; ?>" id="birthday" name="birthday" required="required">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label for="gender">GENDER</label>
                                        <select id="gender" name="gender" class="form-control" required="">
                                            <option value="">Select Gender</option>
                                            <option <?php 
                                        if (isset($user_info_result['gender'])) {
                                            if ($user_info_result['gender'] == "Male") {
                                                echo 'selected';
                                            }
                                        }
                                         ?> value="Male">Male</option>
                                            <option <?php 
                                        if (isset($user_info_result['gender'])) {
                                            if ($user_info_result['gender'] == "Female") {
                                                echo 'selected';
                                            }
                                        }
                                         ?> value="Female">Female</option>
                                            <option <?php 
                                        if (isset($user_info_result['gender'])) {
                                            if ($user_info_result['gender'] == "Other") {
                                                echo 'selected';
                                            }
                                        }
                                         ?> value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group mb-0 mt-3">
                                <select name="marital_status" class="form-control" required="">
                                    <option value="">Marital Status</option>
                                    <option <?= isset($user_info_result['marital_status']) && $user_info_result['marital_status'] == 'Single' ? 'selected' : ''; ?> value="Single">Single</option>
                                    <option <?= isset($user_info_result['marital_status']) && $user_info_result['marital_status'] == 'Married' ? 'selected' : ''; ?> value="Married">Married</option>
                                    <option <?= isset($user_info_result['marital_status']) && $user_info_result['marital_status'] == 'Widowed' ? 'selected' : ''; ?> value="Widowed">Widowed</option>
                                </select>
                            </div>

                            <div class="form-group mb-0 mt-3">
                                <input class="form-control" type="text" placeholder="Contact Number" name="phone" value="<?= isset($user_info_result['phone']) ? $user_info_result['phone'] : ''; ?>" required="required" pattern="01[3|4|5|6|7|8|9][0-9]{8}">
                                <?php echo isset($user->phone) ? $user->phone : ''; ?>
                            </div>
                            <div class="form-group mb-0 mt-3">
                                <input class="form-control" type="number" min="0" placeholder="NID" name="nid" value="<?= isset($user_info_result['nid']) ? $user_info_result['nid'] : ''; ?>" required="required" readonly="">
                            </div>
                            
                            <div class="form-group mb-0 mt-3">
                                <input class="form-control" type="text" value="<?= isset($user_info_result['address']) ? $user_info_result['address'] : ''; ?>" placeholder="Address" name="address" required="required">
                            </div>

                            <div class="mt-3 text-right">
                                <input class="btn btn-primary btn-sm" type="submit" name="update_profile" value="Update">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
        <br>
    </div>
</main>
<?php require_once "inc/footer.php"; ?>