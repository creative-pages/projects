<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class Position {
	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}

	public function insertPosition($data) {
		$pos = $this->fm->validation($data['pos']);
		$annual_leave = $this->fm->validation($data['annual_leave']);
		$casual_leave = $this->fm->validation($data['casual_leave']);
		$medical_leave = $this->fm->validation($data['medical_leave']);
		$maternity_leave = $this->fm->validation($data['maternity_leave']);
		$festival_leave = $this->fm->validation($data['festival_leave']);

		$dept_check = "SELECT * FROM `position` WHERE `pos` = '$pos'";
		$dept_check_result = $this->db->select($dept_check);

		if ($dept_check_result == "") {
			$sql = "INSERT INTO `position`(`pos`, `annual_leave`, `casual_leave`, `medical_leave`, `maternity_leave`, `festival_leave`) VALUES ('$pos', '$annual_leave', '$casual_leave', '$medical_leave', '$maternity_leave', '$festival_leave')";
			$result = $this->db->insert($sql);

			if ($result) {
				return '<div class="alert alert-success mb-0">Position added successfully.</div>';
			} else {
				return '<div class="alert alert-warning mb-0">Position does not added!</div>';
			}
		} else {
			return '<div class="alert alert-warning mb-0">This position already exist!</div>';
		}
	}

	public function viewAllPosition() {
		$sql = "SELECT * FROM `position`";
		$result = $this->db->select($sql);
		return $result;
	}

	public function singlePosition($id) {
		$sql = "SELECT * FROM `position` WHERE `id` = '$id'";
		$result = $this->db->update($sql);
		return $result;
	}

	public function updatePosition($data) {
		$id = $this->fm->validation($data['id']);
		$pos = $this->fm->validation($data['pos']);
		$annual_leave = $this->fm->validation($data['annual_leave']);
		$casual_leave = $this->fm->validation($data['casual_leave']);
		$medical_leave = $this->fm->validation($data['medical_leave']);
		$maternity_leave = $this->fm->validation($data['maternity_leave']);
		$festival_leave = $this->fm->validation($data['festival_leave']);

		$pos_check = "SELECT * FROM `position` WHERE `pos` = '$pos'";
		$pos_check_result = $this->db->select($pos_check);

		$self_pos_check = "SELECT * FROM `position` WHERE `id` = '$id'";
		$self_pos_checked = $this->db->select($self_pos_check);
		if ($self_pos_checked) {
			$self_pos_checked_result = $self_pos_checked->fetch_assoc();
		}
		if ($pos_check_result == NULL || $self_pos_checked_result['pos'] == $pos) {
			$sql = "UPDATE `position` SET `pos` = '$pos', `annual_leave` = '$annual_leave', `casual_leave` = '$casual_leave', `medical_leave` = '$medical_leave', `maternity_leave` = '$maternity_leave', `festival_leave` = '$festival_leave' WHERE `id` = '$id'";
			$result = $this->db->update($sql);
			if ($result) {
				return '<div class="alert alert-success mb-0">Department updated successfully.</div>';
			} else {
				return '<div class="alert alert-warning mb-0">Department does not updated!</div>';
			}
		} else {
			return '<div class="alert alert-warning mb-0">This position already exist!</div>';
		}
	}

	public function deletePosition($id) {
		$sql = "DELETE FROM `position` WHERE `id` = '$id'";
		$result = $this->db->delete($sql);
		return $result;
	}
}

?>