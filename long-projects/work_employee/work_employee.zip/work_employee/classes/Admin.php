<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Session.php");
Session::init();
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class Admin {
	public $email;
	public $password;

	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}

	public function adminLogin($data) {
		$email = $this->fm->validation($data['email']);
		$password = $this->fm->validation($data['password']);


		if (empty($email)) {
			$this->email = '<div class="alert alert-warning">Please enter your email.</div>';
		}
		if (empty($password)) {
			$this->password = '<div class="alert alert-warning">Please enter your Password.</div>';
		}

		if ($email !== '' && $password !== '') {
			$email_check = "SELECT * FROM `admin` WHERE `email` = '$email'";
			$email_check_result = $this->db->select($email_check);
			if ($email_check_result != false) {
				$passwordCheck = $email_check_result->fetch_assoc();
				if ($passwordCheck['password'] == $password) {
					Session::set('login', true);
					Session::set('admin_id', $passwordCheck['id']);
					Session::set('admin_email', $passwordCheck['email']);
					Session::set('admin_password', $passwordCheck['password']);
					Session::set('status', $passwordCheck['status']);
					header("Location: dashboard.php");
				} else {
					$this->password = '<div class="alert alert-warning">Password does not matched!</div>';
				}
			} else {
				$this->email = '<div class="alert alert-warning">This email is wrong!</div>';
			}
		}
	}

	public function passwordRecovery($data) {
		$email = $this->fm->validation($data['email']);

		if (!empty($email)) {
			$query = "SELECT * FROM `admin` WHERE `email` = '$email'";
			$result = $this->db->select($query);
			if ($result != false) {
				$value = $result->fetch_assoc();
				$userId = $value['id'];
				$email = $value['email'];

				$text = substr($email, 0, 5);
				$rand = rand(100000000, 999999999);
				$newpass = $text . $rand;

				
				$from = 'Orbit Graphics';
				$headers = "From: $from\n";
				$headers .= 'MIME-Version: 1.0' . "r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "r\n";
				$subject = "Your Password";
				$message = "Your Email is: " . $email . " and Password is: " . $newpass . " Please visit website to login.";
				// <a href='https://portal.orbitgraphics.com/login.php'>visit</a>
				$sendMail = mail($email, $subject, $message);
				if ($sendMail) {
					$update_query = "UPDATE `admin` SET `password` = '$newpass' WHERE `id` = '$userId'";
					$update_result = $this->db->update($update_query);

					$recoveryMsg = '<div class="alert alert-success">Please check your email.</div>';
					return $recoveryMsg;
				} else {
					$recoveryMsg = '<div class="alert alert-warning">Failed to send recover password!</div>';
					return $recoveryMsg;
				}
			} else {
				$recoveryMsg = '<div class="alert alert-warning">Email Not Found!</div>';
				return $recoveryMsg;
			}
		} else {
			$recoveryMsg = '<div class="alert alert-warning">Please enter your email.</div>';
			return $recoveryMsg;
		}
	}

	public $old_file;
	public $new_password;
	public $confirm_password;
	public function changePassword($data) {
		$admin_id = Session::get('admin_id');
		$admin_password = Session::get('admin_password');

		$old_password = $this->fm->validation($data['old_password']);
		$new_password = $this->fm->validation($data['new_password']);
		$confirm_password = $this->fm->validation($data['confirm_password']);

		if (empty($old_password)) {
			$this->old_password = '<div class="alert alert-warning mb-0">Please enter your old password.</div>';
		}
		if (empty($new_password)) {
			$this->new_password = '<div class="alert alert-warning mb-0">Please enter new password.</div>';
		} elseif (strlen($new_password) < 6) {
			$this->new_password = '<div class="alert alert-warning mb-0">Password should be minimum 6 characters.</div>';
			return false;
		}
		if (empty($confirm_password)) {
			$this->confirm_password = '<div class="alert alert-warning mb-0">Please enter old password.</div>';
		}

		if ($old_password && $new_password && $confirm_password) {
			if ($old_password == $admin_password) {
				if ($new_password == $confirm_password) {
					$query = "UPDATE `admin` SET `password` = '$new_password' WHERE `id` = '$admin_id'";
					$result = $this->db->update($query);
					if ($result) {
						session_destroy();
						$updateMsg = '<div class="alert alert-success mb-0">Password changed successfully.</div>';
						return $updateMsg;
					} else {
						$updateMsg = '<div class="alert alert-warning mb-0">Password does not changed.</div>';
						return $updateMsg;
					}
				} else {
					$this->confirm_password = '<div class="alert alert-warning mb-0">Confirm password does not matched!.</div>';
				}
			} else {
				$this->old_password = '<div class="alert alert-warning mb-0">Old password does not matched!</div>';
			}
		}
	}
}

?>