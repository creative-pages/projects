<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class Contact {

	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}
	public function insertMessage($data) {
		if (isset($data['user_id'])) {
			$user_id = $data['user_id'];
		} else {
			$user_id = Session::get('user_id');
		}
		$subject = $this->fm->validation($data['subject']);
		$description = $this->fm->validation($data['description']);
		$admin = Session::get('status');
		if ($admin == 'admin') {
			$state = 'reply';
		} else {
			$state = 'sent';
		}

		if ($user_id && $subject && $description) {
			$query = "INSERT INTO `message`(`user_id`, `subject`, `description`, `state`) VALUES ('$user_id', '$subject', '$description', '$state')";
			$result = $this->db->insert($query);
			if ($user_id = 4) {
				if ($result) {
					$addMsg = '<div class="alert alert-success mb-0 mt-5">Message replied successfully.</div>';
					return $addMsg;
				} else {
					$addMsg = '<div class="alert alert-warning mb-0 mt-5">Message does not replied.</div>';
					return $addMsg;
				}
			} else {
				if ($result) {
					$addMsg = '<div class="alert alert-success mb-0 mt-5">Message sent successfully.</div>';
					return $addMsg;
				} else {
					$addMsg = '<div class="alert alert-warning mb-0 mt-5">Message does not sent.</div>';
					return $addMsg;
				}
			}
		}
	}

	// for user
	public function inboxMessage() {
		$user_id = Session::get('user_id');
		$sql = "SELECT * FROM `message` WHERE `user_id` = '$user_id' AND `state` = 'reply' AND `status` = '0' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	public function seenboxMessage() {
		$user_id = Session::get('user_id');
		$sql = "SELECT * FROM `message` WHERE `user_id` = '$user_id' AND `state` = 'reply' AND `status` = '1' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	public function sentMessage() {
		$user_id = Session::get('user_id');
		$sql = "SELECT * FROM `message` WHERE `user_id` = '$user_id' AND `state` = 'sent' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}

	// for admin
	public function inboxAdminMessage() {
		$sql = "SELECT * FROM `message` WHERE `state` = 'sent' AND `status` = '0' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	public function seenboxAdminMessage() {
		$sql = "SELECT * FROM `message` WHERE `state` = 'sent' AND `status` = '1' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	public function sentAdminMessage() {
		$sql = "SELECT * FROM `message` WHERE `state` = 'reply' ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	public function allMessage() {
		$query = "SELECT `message`.*, `users`.`first_name`, `users`.`last_name`, `users`.`email`, `users`.`phone`
			FROM `message`
			INNER JOIN `users` ON `users`.`id` = `message`.`user_id`";
		$result = $this->db->select($query);
		return $result;
	}
	public function viewMessage($id) {
		$query = "SELECT `message`.*, `users`.`first_name`, `users`.`last_name`, `users`.`email`, `users`.`phone`
			FROM `message`
			INNER JOIN `users` ON `users`.`id` = `message`.`user_id`
			WHERE `message`.`id` = '$id'";
		$result = $this->db->select($query);
		$sql = "UPDATE `message` SET `status` = '1' WHERE `id` = '$id'";
		$this->db->update($sql);
		return $result;
	}
	public function changeStatus($id = NULL) {
		$query = "UPDATE `message` SET `status` = '1' WHERE `id` = '$id'";
		$this->db->update($query);
	}
	// public function deleteMessage($id) {
	// 	$query = "DELETE FROM `contact` WHERE `id` = '$id'";
	// 	$result = $this->db->delete($query);
	// 	if ($result) {
	// 		header("Location: inbox.php");
	// 	}
	// }
}

?>