<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Session.php");
Session::init();
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class User {
	public $employee_id;
	public $email;
	public $phone;

	// for user login
	// public $email; from top
	public $password;
	public $token;

	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}

	public function addUser($data) {
		$employee_id = $this->fm->validation($data['employee_id']);
		$first_name = $this->fm->validation($data['first_name']);
		$last_name = $this->fm->validation($data['last_name']);
		$email = $this->fm->validation($data['email']);
		$dept = $this->fm->validation($data['dept']);
		$pos = $this->fm->validation($data['pos']);
		$salary = $this->fm->validation($data['salary']);
		$hire_date = $this->fm->validation($data['hire_date']);
		$birthday = $this->fm->validation($data['birthday']);
		$gender = $this->fm->validation($data['gender']);
		$marital_status = $this->fm->validation($data['marital_status']);
		$phone = $this->fm->validation($data['phone']);
		$nid = $this->fm->validation($data['nid']);
		$address = $this->fm->validation($data['address']);

		$text = substr($email, 0, 5);
		$rand = rand(100000000, 999999999);
		$password = $text . $rand;


		$permited  = array('jpg', 'jpeg', 'png', 'gif');
	    $file_name = $_FILES['photo']['name'];
	    $file_size = $_FILES['photo']['size'];
	    $file_temp = $_FILES['photo']['tmp_name'];

	    $div = explode('.', $file_name);
	    $file_ext = strtolower(end($div));
	    $photo = substr(md5(time()), 0, 10).'.'.$file_ext;

	    	$employee_id_check = "SELECT * FROM `users` WHERE `employee_id` = '$employee_id'";
			$employee_id_check_result = $this->db->select($employee_id_check);
			if ($employee_id_check_result == NULL) {
				$email_check = "SELECT * FROM `users` WHERE `email` = '$email'";
				$email_check_result = $this->db->select($email_check);
				if ($email_check_result == NULL) {
					$phone_check = "SELECT * FROM `users` WHERE `phone` = '$phone'";
					$phone_check_result = $this->db->select($phone_check);
					if ($phone_check_result == NULL) {
						if ($file_name) {
							if ($file_size > 2097152) {
						     	$this->image = '<div class="alert alert-warning mb-0">Image Size should be less then 2MB!
						     </div>';
						     return $image;
						    } elseif (in_array($file_ext, $permited) === false) {
						     	$this->image = "<div class='alert alert-warning mb-0'>You can upload only:-"
						     .implode(', ', $permited)."</div>";
						    } else {
						    	$sql = "INSERT INTO `users`(`employee_id`, `first_name`, `last_name`, `email`, `password`, `dept`, `pos`, `salary`, `hire_date`, `birthday`, `gender`, `marital_status`, `phone`, `nid`, `address`, `photo`) VALUES ('$employee_id', '$first_name', '$last_name', '$email', '$password', '$dept', '$pos', '$salary', '$hire_date', '$birthday', '$gender', '$marital_status', '$phone', '$nid', '$address', '$photo')";
						    	$result = $this->db->insert($sql);
								if ($result) {
									move_uploaded_file($file_temp, 'uploadFiles/' . $photo);
									// access information to employee
									$from = 'Orbit Graphics';
									$headers = "From: $from\n";
									$headers .= 'MIME-Version: 1.0' . "r\n";
									$headers .= 'Content-type: text/html; charset=iso-8859-1' . "r\n";
									$subject = "Your Login Information";
									$message = "Your Email is: " . $email . " and Password is: " . $password . " Please visit work.orbitgraphics.com to login.";
									// <a href='https://portal.orbitgraphics.com/login.php'>visit</a>
									$sendMail = mail($email, $subject, $message);

									return '<div class="alert alert-success mb-0">Account created successfully.</div>';
								} else {
									return '<div class="alert alert-warning mb-0">Account does not created!</div>';
								}
						    }
						}
					} else {
						$this->phone = '<div class="alert alert-warning mb-0">This phone number has already been exist!</div>';
					}
				} else {
					$this->email = '<div class="alert alert-warning mb-0">This email has already been exist!</div>';
				}
			} else {
				$this->employee_id = '<div class="alert alert-warning mb-0">This employee id has already been exist!</div>';
			}

	}

	public function userLogin($data) {
		$email = $this->fm->validation($data['email']);
		$password = $this->fm->validation($data['password']);
		$token = $this->fm->validation($data['token']);


		if (empty($email)) {
			$this->email = '<div class="alert alert-warning">Please enter your email.</div>';
		}
		if (empty($password)) {
			$this->password = '<div class="alert alert-warning">Please enter your Password.</div>';
		}
		if (empty($token)) {
			$this->token = "<div class='alert alert-warning'>Please enter today's token.</div>";
		}

		if ($email !== '' && $password !== '' && $token !== '') {
			$email_check = "SELECT * FROM `users` WHERE `email` = '$email'";
			$email_check_result = $this->db->select($email_check);
			if ($email_check_result != false) {
				$passwordCheck = $email_check_result->fetch_assoc();
				if ($passwordCheck['password'] == $password) {
					$token_result = $this->singleToken();
					$token_result = $token_result->fetch_assoc();
					if ($token_result['token'] == $token) {
						Session::set('login', true);
						Session::set('user_id', $passwordCheck['id']);
						Session::set('employee_id', $passwordCheck['employee_id']);
						Session::set('password', $passwordCheck['password']);
						header("Location: index.php");
					} else {
						$this->status = "<div class='alert alert-warning'>Today's token does not match!</div>";
					}
				} else {
					$this->password = '<div class="alert alert-warning">Password does not matched!</div>';
				}
			} else {
				$this->email = '<div class="alert alert-warning">This email is wrong!</div>';
			}
		}
	}

	public function passwordRecovery($data) {
		$email = $this->fm->validation($data['email']);

		if (!empty($email)) {
			$query = "SELECT * FROM `users` WHERE `email` = '$email'";
			$result = $this->db->select($query);
			if ($result != false) {
				$value = $result->fetch_assoc();
				$userId = $value['id'];
				$fullname = $value['first_name'] . ' ' . $value['last_name'];

				$text = substr($email, 0, 5);
				$rand = rand(100000000, 999999999);
				$newpass = $text . $rand;

				
				$from = 'Orbit Graphics';
				$headers = "From: $from\n";
				$headers .= 'MIME-Version: 1.0' . "r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "r\n";
				$subject = "Your Password";
				$message = "Your Name is: " . $fullname . " and Password is: " . $newpass . " Please visit website to login.";
				// <a href='https://portal.orbitgraphics.com/login.php'>visit</a>
				$sendMail = mail($email, $subject, $message);
				if ($sendMail) {
					$update_query = "UPDATE `users` SET `password` = '$newpass' WHERE `id` = '$userId'";
					$update_result = $this->db->update($update_query);

					$recoveryMsg = '<div class="alert alert-success">Please check your email.</div>';
					return $recoveryMsg;
				} else {
					$recoveryMsg = '<div class="alert alert-warning">Failed to send recover password!</div>';
					return $recoveryMsg;
				}
			} else {
				$recoveryMsg = '<div class="alert alert-warning">Email Not Found!</div>';
				return $recoveryMsg;
			}
		} else {
			$recoveryMsg = '<div class="alert alert-warning">Please enter your email.</div>';
			return $recoveryMsg;
		}
	}

	public function singleUser($id) {
		$id = $this->fm->validation($id);
		$query = "SELECT * FROM `users` WHERE `id` = '$id'";
		$result = $this->db->select($query);
		return $result;
	}
	public function singleUserByEmployeeId($employee_id) {
		$employee_id = $this->fm->validation($employee_id);
		$query = "SELECT * FROM `users` WHERE `employee_id` = '$employee_id'";
		$result = $this->db->select($query);
		return $result;
	}

	public function updateUser($data) {

		$id = $this->fm->validation($data['id']);

		$employee_id = $this->fm->validation($data['employee_id']);
		$first_name = $this->fm->validation($data['first_name']);
		$last_name = $this->fm->validation($data['last_name']);
		$email = $this->fm->validation($data['email']);
		$dept = $this->fm->validation($data['dept']);
		$pos = $this->fm->validation($data['pos']);
		$salary = $this->fm->validation($data['salary']);
		$hire_date = $this->fm->validation($data['hire_date']);
		$birthday = $this->fm->validation($data['birthday']);
		$gender = $this->fm->validation($data['gender']);
		$marital_status = $this->fm->validation($data['marital_status']);
		$phone = $this->fm->validation($data['phone']);
		$nid = $this->fm->validation($data['nid']);
		$address = $this->fm->validation($data['address']);

		$text = substr($email, 0, 5);
		$rand = rand(100000000, 999999999);
		$password = $text . $rand;


		$employee_id_check = "SELECT * FROM `users` WHERE `employee_id` = '$employee_id'";
		$employee_id_check_result = $this->db->select($employee_id_check);

		$self_employee_id_check = "SELECT * FROM `users` WHERE `id` = '$id'";
		$self_employee_id_checked = $this->db->select($self_employee_id_check);
		if ($self_employee_id_checked) {
			$self_employee_id_checked_result = $self_employee_id_checked->fetch_assoc();
		}
		if ($employee_id_check_result == NULL || $self_employee_id_checked_result['employee_id'] == $employee_id) {
			$email_check = "SELECT * FROM `users` WHERE `email` = '$email'";
			$email_check_result = $this->db->select($email_check);

			$self_email_check = "SELECT * FROM `users` WHERE `id` = '$id'";
			$self_email_checked = $this->db->select($self_email_check);
			if ($self_email_checked) {
				$self_email_checked_result = $self_email_checked->fetch_assoc();
			}
			if ($email_check_result == NULL || $self_email_checked_result['email'] == $email) {
				$phone_check = "SELECT * FROM `users` WHERE `phone` = '$phone'";
				$phone_check_result = $this->db->select($phone_check);

				$self_phone_check = "SELECT * FROM `users` WHERE `id` = '$id'";
				$self_phone_checked = $this->db->select($self_phone_check);
				if ($self_phone_checked) {
					$self_phone_checked_result = $self_phone_checked->fetch_assoc();
				}
				if ($phone_check_result == NULL || $self_phone_checked_result['phone'] == $phone) {
				    	$sql = "UPDATE `users` SET `first_name`= '$first_name',`last_name`= '$last_name',`email`= '$email',`password`= '$password',`dept`= '$dept',`pos`= '$pos',`salary`= '$salary',`hire_date`= '$hire_date',`birthday`= '$birthday',`gender`= '$gender',`marital_status`= '$marital_status',`phone`= '$phone',`nid`= '$nid',`address`= '$address' WHERE `id` = '$id'";
				    	$result = $this->db->update($sql);
						if ($result) {
							// access information to employee
							$from = 'Orbit Graphics';
							$headers = "From: $from\n";
							$headers .= 'MIME-Version: 1.0' . "r\n";
							$headers .= 'Content-type: text/html; charset=iso-8859-1' . "r\n";
							$subject = "Your Login Information";
							$message = "Your Email is: " . $email . " and Password is: " . $password . " Please visit work.orbitgraphics.com to login.";
							// <a href='https://portal.orbitgraphics.com/login.php'>visit</a>
							$sendMail = mail($email, $subject, $message);
							return '<div class="alert alert-success">Account updated successfully.</div>';
						} else {
							return '<div class="alert alert-warning">Account does not updated!</div>';
						}
						
				} else {
					$this->phone = '<div class="alert alert-warning mb-0">This phone number has already been exist!</div>';
				}
			} else {
				$this->email = '<div class="alert alert-warning mb-0">This email has already been exist!</div>';
			}
		} else {
			$this->employee_id = '<div class="alert alert-warning mb-0">This employee id has already been exist!</div>';
		}

	}

	public function updateProfile($data) {

		$id = $this->fm->validation($data['id']);

		$first_name = $this->fm->validation($data['first_name']);
		$last_name = $this->fm->validation($data['last_name']);
		$email = $this->fm->validation($data['email']);
		$birthday = $this->fm->validation($data['birthday']);
		$gender = $this->fm->validation($data['gender']);
		$marital_status = $this->fm->validation($data['marital_status']);
		$phone = $this->fm->validation($data['phone']);
		$address = $this->fm->validation($data['address']);


			$email_check = "SELECT * FROM `users` WHERE `email` = '$email'";
			$email_check_result = $this->db->select($email_check);

			$self_email_check = "SELECT * FROM `users` WHERE `id` = '$id'";
			$self_email_checked = $this->db->select($self_email_check);
			if ($self_email_checked) {
				$self_email_checked_result = $self_email_checked->fetch_assoc();
			}
			if ($email_check_result == NULL || $self_email_checked_result['email'] == $email) {
				$phone_check = "SELECT * FROM `users` WHERE `phone` = '$phone'";
				$phone_check_result = $this->db->select($phone_check);

				$self_phone_check = "SELECT * FROM `users` WHERE `id` = '$id'";
				$self_phone_checked = $this->db->select($self_phone_check);
				if ($self_phone_checked) {
					$self_phone_checked_result = $self_phone_checked->fetch_assoc();
				}
				if ($phone_check_result == NULL || $self_phone_checked_result['phone'] == $phone) {
				    	$sql = "UPDATE `users` SET `first_name`= '$first_name',`last_name`= '$last_name',`email`= '$email',`birthday`= '$birthday',`gender`= '$gender',`marital_status`= '$marital_status',`phone`= '$phone',`address`= '$address' WHERE `id` = '$id'";
				    	$result = $this->db->update($sql);
						if ($result) {
							return '<div class="alert alert-success">Account updated successfully.</div>';
						} else {
							return '<div class="alert alert-warning">Account does not updated!</div>';
						}
						
				} else {
					$this->phone = '<div class="alert alert-warning mb-0">This phone number has already been exist!</div>';
				}
			} else {
				$this->email = '<div class="alert alert-warning mb-0">This email has already been exist!</div>';
			}

	}

	public function updateUserPhoto($data) {
		$id = $this->fm->validation($data['id']);

		$old_file = $this->fm->validation($data['old_file']);
		$permited  = array('jpg', 'jpeg', 'png', 'gif');
	    $file_name = $_FILES['photo']['name'];
	    $file_size = $_FILES['photo']['size'];
	    $file_temp = $_FILES['photo']['tmp_name'];

	    $div = explode('.', $file_name);
	    $file_ext = strtolower(end($div));
	    $photo = substr(md5(time()), 0, 10).'.'.$file_ext;

	    if ($file_name) {
			if ($file_size > 2097152) {
		     	$this->image = '<div class="alert alert-warning mb-0">Image Size should be less then 2MB!
		     </div>';
		     return false;
		    } elseif (in_array($file_ext, $permited) === false) {
		     	$this->image = "<div class='alert alert-warning mb-0'>You can upload only:-"
		     .implode(', ', $permited)."</div>";
		     return false;
		    } else {
		    	$sql = "UPDATE `users` SET `photo`='$photo' WHERE `id` = '$id'";
		    	$result = $this->db->update($sql);
				if ($result) {
					if ($old_file) {
						unlink("uploadFiles/" . $old_file);
					}
			    	move_uploaded_file($file_temp, 'uploadFiles/' . $photo);
			    	header("Location: profile.php");
					// return '<div class="alert alert-success">Photo updated successfully.</div>';
				} else {
					return '<div class="alert alert-warning">Photo does not updated!</div>';
				}
		    }
		}
	}

	public $old_file;
	public $new_password;
	public $confirm_password;
	public function changePassword($data) {
		$user_id = Session::get('user_id');
		$password_match = Session::get('password');

		$old_password = $this->fm->validation($data['old_password']);
		$new_password = $this->fm->validation($data['new_password']);
		$confirm_password = $this->fm->validation($data['confirm_password']);

		if (empty($old_password)) {
			$this->old_password = '<div class="alert alert-warning mb-0">Please enter your old password.</div>';
		}
		if (empty($new_password)) {
			$this->new_password = '<div class="alert alert-warning mb-0">Please enter new password.</div>';
		} elseif (strlen($new_password) < 6) {
			$this->new_password = '<div class="alert alert-warning mb-0">Password should be minimum 6 characters.</div>';
			return false;
		}
		if (empty($confirm_password)) {
			$this->confirm_password = '<div class="alert alert-warning mb-0">Please enter old password.</div>';
		}

		if ($old_password && $new_password && $confirm_password) {
			if ($old_password == $password_match) {
				if ($new_password == $confirm_password) {
					$query = "UPDATE `users` SET `password` = '$new_password' WHERE `id` = '$user_id'";
					$result = $this->db->update($query);
					if ($result) {
						session_destroy();
						$updateMsg = '<div class="alert alert-success mb-0">Password changed successfully.</div>';
						return $updateMsg;
					} else {
						$updateMsg = '<div class="alert alert-warning mb-0">Password does not changed.</div>';
						return $updateMsg;
					}
				} else {
					$this->confirm_password = '<div class="alert alert-warning mb-0">Confirm password does not matched!.</div>';
				}
			} else {
				$this->old_password = '<div class="alert alert-warning mb-0">Old password does not matched!</div>';
			}
		}
	}

	// all user list
	public function allUsers() {
		$sql = "SELECT * FROM `users` ORDER BY `id` DESC";
		$result = $this->db->select($sql);
		return $result;
	}
	// delete user
	public function deleteUser($id, $photo) {
		$sql = "DELETE FROM `users` WHERE `id` = '$id'";
		$result = $this->db->delete($sql);
		if ($result) {
			unlink("uploadFiles/" . $photo);
			return $result;
		}
	}

	public function singleToken() {
		$query = "SELECT * FROM `token` WHERE `id` = '1'";
		$result = $this->db->select($query);
		return $result;
	}

	// update token
	public function updateToken($data) {
		$token = $this->fm->validation($data['token']);
		$sql = "UPDATE `token` SET `token` = '$token' WHERE `id` = '1'";
		$result = $this->db->update($sql);
		if ($result) {
			$updateMsg = '<div class="alert alert-success mb-0">Token updated successfully.</div>';
			return $updateMsg;
		} else {
			$updateMsg = '<div class="alert alert-warning mb-0">Token does not updated!</div>';
			return $updateMsg;
		}
	}

	// check in time for user
	public function checkIn() {
		$user_id = Session::get('user_id');
		$employee_id = Session::get('employee_id');

		$check_in = date('Y-m-d h:i:s');
		$date = date('Y-m-d');
		$month = date('Y-m');

		$query = "SELECT * FROM `attendance` WHERE `user_id` = '$user_id' && `employee_id` = '$employee_id' && `date` = '$date'";
		$login_check = $this->db->select($query);

		if ($login_check == NUll) {
			$sql = "INSERT INTO `attendance`(`user_id`, `employee_id`, `check_in`, `date`, `month`) VALUES ('$user_id', '$employee_id', '$check_in', '$date', '$month')";
			$result = $this->db->insert($sql);
		} else {
			$check_in_msg = '<div class="alert alert-warning">Already check in!</div>';
			return $check_in_msg;
		}
	}

	// check in time for user
	public function checkOut() {
		$user_id = Session::get('user_id');
		$employee_id = Session::get('employee_id');

		$check_out = date('Y-m-d h:i:s');
		$date = date('Y-m-d');

		$query = "SELECT * FROM `attendance` WHERE `user_id` = '$user_id' && `employee_id` = '$employee_id' && `date` = '$date' && `check_out` = '0000-00-00 00:00:00'";
		$check_out_check = $this->db->select($query);
		if ($check_out_check) {
			$check_out_check_result = $check_out_check->fetch_assoc();

			// subtract two times
			$datetime1 = new DateTime($check_out);
			$datetime2 = new DateTime($check_out_check_result['check_in']);
			$interval = $datetime1->diff($datetime2);
			$time = $interval->format('%H:%i');
		}


		if ($check_out_check != NUll) {
			$sql = "UPDATE `attendance` SET `check_out` = '$check_out', `time` = '$time' WHERE `user_id` = '$user_id' && `employee_id` = '$employee_id' && `date` = '$date' && `check_out` = '0000-00-00 00:00:00'";
			$result = $this->db->update($sql);
		} else {
			$check_out_msg = '<div class="alert alert-warning">Already check out!</div>';
			return $check_out_msg;
		}
	}

	// today's check in & check out details
	public function todayCheckInOut() {
		$user_id = Session::get('user_id');
		$employee_id = Session::get('employee_id');

		$date = date('Y-m-d');

		$query = "SELECT * FROM `attendance` WHERE `user_id` = '$user_id' && `employee_id` = '$employee_id' && `date` = '$date'";
		$login_check = $this->db->select($query);

		return $login_check;

	}

	// monthly attendance
	public function monthlyAtttendance($employee_id, $month) {
		$employee_id = $this->fm->validation($employee_id);
		$month = $this->fm->validation($month);

		$query = "SELECT * FROM `attendance` WHERE `employee_id` = '$employee_id' && `month` = '$month'";
		$monthly_attendance = $this->db->select($query);
		if ($monthly_attendance) {
			return $monthly_attendance;
		}
	}
}

?>