<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class Department {
	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}

	public function insertDepartment($data) {
		$dept = $this->fm->validation($data['dept']);

		$dept_check = "SELECT * FROM `department` WHERE `dept` = '$dept'";
		$dept_check_result = $this->db->select($dept_check);

		if ($dept_check_result == "") {
			$sql = "INSERT INTO `department`(`dept`) VALUES ('$dept')";
			$result = $this->db->insert($sql);

			if ($result) {
				return '<div class="alert alert-success mb-0">Department added successfully.</div>';
			} else {
				return '<div class="alert alert-warning mb-0">Department does not added!</div>';
			}
		} else {
			return '<div class="alert alert-warning mb-0">This department already exist!</div>';
		}
	}

	public function viewAllDepartment() {
		$sql = "SELECT * FROM `department`";
		$result = $this->db->select($sql);
		return $result;
	}

	public function singleDepartment($id) {
		$sql = "SELECT * FROM `department` WHERE `id` = '$id'";
		$result = $this->db->update($sql);
		return $result;
	}

	public function updateDepartment($data) {
		$id = $this->fm->validation($data['id']);
		$dept = $this->fm->validation($data['dept']);

		$dept_check = "SELECT * FROM `department` WHERE `dept` = '$dept'";
		$dept_check_result = $this->db->select($dept_check);

		$self_dept_check = "SELECT * FROM `department` WHERE `id` = '$id'";
		$self_dept_checked = $this->db->select($self_dept_check);
		if ($self_dept_checked) {
			$self_dept_checked_result = $self_dept_checked->fetch_assoc();
		}
		if ($dept_check_result == NULL || $self_dept_checked_result['dept'] == $dept) {
			$sql = "UPDATE `department` SET `dept` = '$dept' WHERE `id` = '$id'";
			$result = $this->db->update($sql);
			if ($result) {
				return '<div class="alert alert-success mb-0">Department updated successfully.</div>';
			} else {
				return '<div class="alert alert-warning mb-0">Department does not updated!</div>';
			}
		} else {
			return '<div class="alert alert-warning mb-0">This department already exist!</div>';
		}
	}

	public function deleteDepartment($id) {
		$sql = "DELETE FROM `department` WHERE `id` = '$id'";
		$result = $this->db->delete($sql);
		return $result;
	}
}

?>