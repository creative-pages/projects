<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Database.php");
include_once ($path . "/../helpers/Format.php");

class Leave {
	public $db;
	public $fm;

	public function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}

	public function userPositionLeave($user_position) {
		$sql = "SELECT * FROM `position` WHERE `pos` = '$user_position';";
		$result = $this->db->select($sql);
		return $result;
	}

	public function requestLeave($data) {
		$employee_id = $this->fm->validation($data['employee_id']);
		$employee_name = $this->fm->validation($data['employee_name']);

		$year = date("Y");
		$month = date("Y-m");


		$from_date = $this->fm->validation($data['from_date']);
		$to_date = $this->fm->validation($data['to_date']);
		$days = $this->fm->validation($data['days']);
		$reason = $this->fm->validation($data['reason']);
		$description = $this->fm->validation($data['description']);



		$sql = "INSERT INTO `leave_request`(`employee_id`, `employee_name`, `from_date`, `to_date`, `days`, `reason`, `description`, `status`, `year`, `month`) VALUES ('$employee_id', '$employee_name', '$from_date', '$to_date', '$days', '$reason', '$description', 'pending', '$year', '$month')";
		$result = $this->db->insert($sql);

		if ($result) {
			return '<div class="alert alert-success mb-0">Leave requested successfully.</div>';
		} else {
			return '<div class="alert alert-warning mb-0">Leave does not requested!</div>';
		}
	}

	public function pendingLeave() {
		$employee_id = Session::get('employee_id');
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'pending' && `employee_id` = '$employee_id'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function acceptedLeave() {
		$employee_id = Session::get('employee_id');
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'accepted' && `employee_id` = '$employee_id'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function cancelledLeave() {
		$employee_id = Session::get('employee_id');
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'cancelled' && `employee_id` = '$employee_id'";
		$result = $this->db->select($sql);
		return $result;
	}

	// for admin
	public function adminPendingLeave() {
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'pending'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function adminAcceptedLeave() {
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'accepted'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function adminCancelledLeave() {
		$sql = "SELECT * FROM `leave_request` WHERE `status` = 'cancelled'";
		$result = $this->db->select($sql);
		return $result;
	}

	// accept leave
	public function acceptLeave($id) {
		$sql = "UPDATE `leave_request` SET `status` = 'accepted' WHERE `id` = '$id'";
		$result = $this->db->update($sql);
		return $result;
	}
	// cancel leave
	public function cancelLeave($id) {
		$sql = "UPDATE `leave_request` SET `status` = 'cancelled' WHERE `id` = '$id'";
		$result = $this->db->update($sql);
		return $result;
	}


	public function deleteLeave($id) {
		$sql = "DELETE FROM `leave_request` WHERE `id` = '$id'";
		$result = $this->db->delete($sql);
		return $result;
	}

	// available leave by type
	public function yearlyAnnualLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS annual_leave FROM `leave_request` WHERE `reason` = 'Annual Leave' && (`status` = 'pending' || `status` = 'accepted') && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyCasualLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS casual_leave FROM `leave_request` WHERE `reason` = 'Casual Leave' && (`status` = 'pending' || `status` = 'accepted') && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyMedicalLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS medical_leave FROM `leave_request` WHERE `reason` = 'Medical Leave' && (`status` = 'pending' || `status` = 'accepted') && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyMaternityLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS maternity_leave FROM `leave_request` WHERE `reason` = 'Maternity Leave' && (`status` = 'pending' || `status` = 'accepted') && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyFestivalLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS festival_leave FROM `leave_request` WHERE `reason` = 'Festival Leave' && (`status` = 'pending' || `status` = 'accepted') && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}

	// accepted leave by type
	public function yearlyAnnualAcceptedLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS annual_leave FROM `leave_request` WHERE `reason` = 'Annual Leave' && `status` = 'accepted' && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyCasualAcceptedLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS casual_leave FROM `leave_request` WHERE `reason` = 'Casual Leave' && `status` = 'accepted' && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyMedicalAcceptedLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS medical_leave FROM `leave_request` WHERE `reason` = 'Medical Leave' && `status` = 'accepted' && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyMaternityAcceptedLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS maternity_leave FROM `leave_request` WHERE `reason` = 'Maternity Leave' && `status` = 'accepted' && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}
	public function yearlyFestivalAcceptedLeave($employee_id, $year) {
		$employee_id = $this->fm->validation($employee_id);
		$year = $this->fm->validation($year);

		$sql = "SELECT SUM(`days`) AS festival_leave FROM `leave_request` WHERE `reason` = 'Festival Leave' && `status` = 'accepted' && `employee_id` = '$employee_id' && `year` = '$year'";
		$result = $this->db->select($sql);
		return $result;
	}

}

?>