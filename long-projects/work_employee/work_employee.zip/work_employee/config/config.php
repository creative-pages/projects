<?php 
	define("DB_HOST", 'localhost');
	define("DB_USER", 'orbinwpb_portal');
	define("DB_PASS", 'orbinwpb_portal');
	define("DB_NAME", 'orbinwpb_work');
?>