<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>
<?php 




if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_leave'])) {
	if ($_POST['reason'] == 'Annual Leave') {
		$avail_annual = $position_leave_result['annual_leave']-$total_monthlyAnnualLeaves;

		$days = $_POST['days'];
		if ($days <= $avail_annual) {
			$request_leave = $leave->requestLeave($_POST);
		} else {
			$no_off_day = "<div class='alert alert-warning mb-0'>You have only " . $avail_annual . " day's.</div>";
		}
	} elseif ($_POST['reason'] == 'Casual Leave') {
		$avail_casual = $position_leave_result['casual_leave']-$total_monthlyCasualLeaves;

		$days = $_POST['days'];
		if ($days <= $avail_casual) {
			$request_leave = $leave->requestLeave($_POST);
		} else {
			$no_off_day = "<div class='alert alert-warning mb-0'>You have only " . $avail_casual . " day's.</div>";
		}
	} elseif ($_POST['reason'] == 'Medical Leave') {
		$avail_medical = $position_leave_result['medical_leave']-$total_monthlyMedicalLeaves;

		$days = $_POST['days'];
		if ($days <= $avail_medical) {
			$request_leave = $leave->requestLeave($_POST);
		} else {
			$no_off_day = "<div class='alert alert-warning mb-0'>You have only " . $avail_medical . " day's.</div>";
		}
	} elseif ($_POST['reason'] == 'Materninty Leave') {
		$avail_maternity = $position_leave_result['maternity_leave']-$total_monthlyMaternityLeaves;

		$days = $_POST['days'];
		if ($days <= $avail_maternity) {
			$request_leave = $leave->requestLeave($_POST);
		} else {
			$no_off_day = "<div class='alert alert-warning mb-0'>You have only " . $avail_maternity . " day's.</div>";
		}
	} elseif ($_POST['reason'] == 'Festival Leave') {
		$avail_festival = $position_leave_result['festival_leave']-$total_monthlyFestivalLeaves;

		$days = $_POST['days'];
		if ($days <= $avail_festival) {
			$request_leave = $leave->requestLeave($_POST);
		} else {
			$no_off_day = "<div class='alert alert-warning mb-0'>You have only " . $avail_festival . " day's.</div>";
		}
	}
}


?>
<main>
	<div class="container-fluid pt-3">
		<div class="row">
			<div class="col-sm-8 offset-sm-2">
				<div class="card card-1">
					<div class="card-heading">
						<br>
						<span class="text-muted px-3">Request For Leave</span>
					</div>
					<hr class="mb-0">
					<div class="card-body">

						<table class="table table-striped table-hover">
							<tr>
								<th>Leave Type</th>
								<th>Allocated Leave</th>
								<th>Available Leave</th>
							</tr>
							<tr>
								<td>Annual Leave</td>
								<td><?= $position_leave_result['annual_leave']; ?></td>
								<td><?= $avail_annual = $position_leave_result['annual_leave']-$total_yearlyAnnualLeaves; ?></td>
							</tr>
							<tr>
								<td>Casual Leave</td>
								<td><?= $position_leave_result['casual_leave']; ?></td>
								<td><?= $avail_casual = $position_leave_result['casual_leave']-$total_yearlyCasualLeaves; ?></td>
							</tr>
							<tr>
								<td>Medical Leave</td>
								<td><?= $position_leave_result['medical_leave']; ?></td>
								<td><?= $avail_medical = $position_leave_result['medical_leave']-$total_yearlyMedicalLeaves; ?></td>
							</tr>
							<tr>
								<td>Maternity Leave</td>
								<td><?= $position_leave_result['maternity_leave']; ?></td>
								<td><?= $avail_maternity = $position_leave_result['maternity_leave']-$total_yearlyMaternityLeaves; ?></td>
							</tr>
							<tr>
								<td>Festival Leave</td>
								<td><?= $position_leave_result['festival_leave']; ?></td>
								<td><?= $avail_festival = $position_leave_result['festival_leave']-$total_yearlyFestivalLeaves; ?></td>
							</tr>
							<tr>
								<td>Total</td>
								<td>
									<?= $position_leave_result['annual_leave']+$position_leave_result['casual_leave']+$position_leave_result['medical_leave']+$position_leave_result['maternity_leave']+$position_leave_result['festival_leave']; ?>
								</td>
								<td>
									<?= $avail_annual+$avail_casual+$avail_medical+$avail_maternity+$avail_festival; ?>
								</td>
							</tr>
						</table>
						<hr>

						<form action="<?= $_SERVER["PHP_SELF"]; ?>" method="POST" enctype="multipart/form-data">
							
							<div class="form-group mb-0">
								<input class="form-control mt-3" type="hidden" placeholder="Employee ID" value="<?= isset($user_info_result['employee_id']) ? $user_info_result['employee_id'] : ''; ?>" name="employee_id" required="required">
							</div>
							<div class="form-group mb-0">
								<input class="form-control mt-3" type="hidden" placeholder="Employee ID" value="<?= isset($user_info_result['first_name']) ? $user_info_result['first_name'] . ' ' . $user_info_result['last_name'] : ''; ?>" name="employee_name" required="required">
							</div>
							<div class="form-row">
								<div class="col-6">
									<div class="form-group mb-0">
										<label for="from_date">From Date</label>
										<input class="form-control" type="date" placeholder="BIRTHDATE" id="from_date" name="from_date" required="required" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?>>
									</div>
								</div>
								<div class="col-6">
									<div class="form-group mb-0">
										<label for="to_date">To Date</label>
										<input class="form-control" type="date" placeholder="BIRTHDATE" id="to_date" name="to_date" required="required" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?>>
									</div>
								</div>
							</div>

							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="number" min="1" placeholder="Days" name="days" required="" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?>>
								<?= isset($no_off_day) ? $no_off_day : ''; ?>
							</div>
							
							<div class="form-group mb-0 mt-3">
								<select name="reason" class="form-control" required="" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?>>
									<option value="">Select Leave Type</option>
									<option value="Annual Leave">Annual Leave</option>
									<option value="Casual Leave">Casual Leave</option>
									<option value="Medical Leave">Medical Leave</option>
									<option value="Medical Leave">Medical Leave</option>
									<option value="Meternity Leave">Meternity Leave</option>
									<option value="Festival Leave">Festival Leave</option>
								</select>
							</div>
						
							<div class="mt-3 text-right">
								<textarea name="description" class="form-control" rows="5" placeholder="Cause of leave" required="" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?>></textarea>
							</div>
							<div class="mt-3 text-right">
								<input class="btn btn-primary btn-sm" type="submit" name="request_leave" <?= $avail_annual == '0' && $avail_casual == '0' && $avail_medical == '0' && $avail_maternity == '0' && $avail_festival == '0' ? 'disabled' : ''; ?> value="Request">
							</div>
						</form>
						<?php echo isset($request_leave) ? $request_leave : ''; ?>
					</div>
				</div>
			</div>
		</div>
		<br>
	</div>
</main>
<?php require_once "inc/footer.php"; ?>