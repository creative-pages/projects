<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>

<main class="bg-light">
	<div class="container-fluid pt-3">
		<div class="card mb-4">
			<div class="card-header">
				<span>
				<?php 
				if (isset($_GET['pending'])) {
					echo '<b>List of Pending Leave</b>';
				} elseif (isset($_GET['accepted'])) {
					echo '<b>List of Accepted Leave</b>';
				} elseif (isset($_GET['cancelled'])) {
					echo '<b>List of Cancelled Leave</b>';
				}
				?>
				</span>
				<span class="float-right">
					<a href="leave.php?pending" class="badge badge-pill badge-warning text-white"><?= isset($total_pending_leave) ? $total_pending_leave : '0'; ?> Pending</a>
					<a href="leave.php?accepted" class="badge badge-pill badge-info"><?= isset($total_accepted_leave) ? $total_accepted_leave : '0'; ?> Accepted</a>
					<a href="leave.php?cancelled" class="badge badge-pill badge-dark"><?= isset($total_cancelled_leave) ? $total_cancelled_leave : '0'; ?> Cancelled</a>
				</span>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>From Date</th>
								<th>To Date</th>
								<th>Day's</th>
								<th>Reason</th>
								<th>Description</th>
								<th>Status</th>
								<th>Date</th>
							</tr>
						</thead>
						<tbody>
				<?php

		 			if (isset($_GET['pending'])) {
						if ($pending_leave) {
							while ($pending = mysqli_fetch_assoc($pending_leave)) {
							?>
							<tr>
								<td><?= $pending['employee_id']; ?></td>
								<td><?= $pending['employee_name']; ?></td>
								<td><?= $pending['from_date']; ?></td>
								<td><?= $pending['to_date']; ?></td>
								<td><?= $pending['days']; ?></td>
								<td><?= $pending['reason']; ?></td>
								<td><?= $pending['description']; ?></td>
								<td><button class="btn btn-warning btn-sm"><?= $pending['status']; ?></button></td>
								<td><?= $fm->dateFormat($pending['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					} elseif (isset($_GET['accepted'])) {
						if ($accepted_leave) {
							while ($accepted = mysqli_fetch_assoc($accepted_leave)) {
							?>
							<tr>
								<td><?= $accepted['employee_id']; ?></td>
								<td><?= $accepted['employee_name']; ?></td>
								<td><?= $accepted['from_date']; ?></td>
								<td><?= $accepted['to_date']; ?></td>
								<td><?= $accepted['days']; ?></td>
								<td><?= $accepted['reason']; ?></td>
								<td><?= $accepted['description']; ?></td>
								<td><button class="btn btn-warning btn-sm"><?= $accepted['status']; ?></button></td>
								<td><?= $fm->dateFormat($accepted['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					} elseif (isset($_GET['cancelled'])) {
						if ($cancelled_leave) {
							while ($cancelled = mysqli_fetch_assoc($cancelled_leave)) {
							?>
							<tr>
								<td><?= $cancelled['employee_id']; ?></td>
								<td><?= $cancelled['employee_name']; ?></td>
								<td><?= $cancelled['from_date']; ?></td>
								<td><?= $cancelled['to_date']; ?></td>
								<td><?= $cancelled['days']; ?></td>
								<td><?= $cancelled['reason']; ?></td>
								<td><?= $cancelled['description']; ?></td>
								<td><button class="btn btn-warning btn-sm"><?= $cancelled['status']; ?></button></td>
								<td><?= $fm->dateFormat($cancelled['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					}

				?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/footer.php"; ?>