<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>
<?php
if (isset($_GET['employee_id']) && isset($_GET['month'])) {
	$employee_id = $_GET['employee_id'];
	$month = base64_decode($_GET['month']);


	$monthly_attendance = $user->monthlyAtttendance($employee_id, $month);
	if ($monthly_attendance) {
		$total_monthly_attendance = mysqli_num_rows($monthly_attendance);
	}
}
?>
<main>
	<div class="container-fluid pt-3">
		<div class="row">
			<div class="col-sm-7">
				<table class="table table-bordered table-striped">
					<tr>
						<th>Date</th>
						<th>Check In Time</th>
						<th>Check Out Time</th>
						<th>Total Work Hour</th>
					</tr>
					<?php
					if (isset($monthly_attendance)) {
						if ($monthly_attendance) {
							while ($monthly_result = $monthly_attendance->fetch_assoc()) {
							?>
							<tr>
								<td><?= isset($monthly_result['date']) ? $fm->dateFormat($monthly_result['date']) : ''; ?></td>
								<td><?= isset($monthly_result['check_in']) ? date("h:ia", strtotime($monthly_result['check_in']. ' + 4 hours')) : ''; ?></td>
								<td><?= isset($monthly_result['check_out']) && $monthly_result['check_out'] != '0000-00-00 00:00:00' ? date("h:ia", strtotime($monthly_result['check_out']. ' + 4 hours')) : ''; ?></td>
								<td><?= isset($monthly_result['time']) ? $monthly_result['time'] : ''; ?></td>
							</tr>
							<?php
							}
						}
					}
					?>
				</table>
			</div>
			<div class="col-sm-5">
				<div class="card border-0 bg-success text-white mb-3">
					<h3 class="card-header py-4 text-center">Present: <?= isset($total_monthly_attendance) ? $total_monthly_attendance : '0'; ?> Day's</h3>
				</div>
				<table class="table table-striped table-hover">
					<tr>
						<th>Leave Type</th>
						<th>Allocated Leave</th>
						<th>Available Leave</th>
					</tr>
					<tr>
						<td>Annual Leave</td>
						<td><?= $position_leave_result['annual_leave']; ?></td>
						<td><?= $avail_annual = $position_leave_result['annual_leave']-$total_yearlyAnnualAcceptedLeaves; ?></td>
					</tr>
					<tr>
						<td>Casual Leave</td>
						<td><?= $position_leave_result['casual_leave']; ?></td>
						<td><?= $avail_casual = $position_leave_result['casual_leave']-$total_yearlyCasualAcceptedLeaves; ?></td>
					</tr>
					<tr>
						<td>Medical Leave</td>
						<td><?= $position_leave_result['medical_leave']; ?></td>
						<td><?= $avail_medical = $position_leave_result['medical_leave']-$total_yearlyMedicalAcceptedLeaves; ?></td>
					</tr>
					<tr>
						<td>Maternity Leave</td>
						<td><?= $position_leave_result['maternity_leave']; ?></td>
						<td><?= $avail_maternity = $position_leave_result['maternity_leave']-$total_yearlyMaternityAcceptedLeaves; ?></td>
					</tr>
					<tr>
						<td>Festival Leave</td>
						<td><?= $position_leave_result['festival_leave']; ?></td>
						<td><?= $avail_festival = $position_leave_result['festival_leave']-$total_yearlyFestivalAcceptedLeaves; ?></td>
					</tr>
					<tr>
						<td>Total</td>
						<td>
							<?= $position_leave_result['annual_leave']+$position_leave_result['casual_leave']+$position_leave_result['medical_leave']+$position_leave_result['maternity_leave']+$position_leave_result['festival_leave']; ?>
						</td>
						<td>
							<?= $avail_annual+$avail_casual+$avail_medical+$avail_maternity+$avail_festival; ?>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/footer.php"; ?>