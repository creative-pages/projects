<?php 
$path = realpath(dirname(__FILE__));
include_once ($path . '/lib/Session.php');
Session::checkLogin();
include_once ($path . "/classes/Admin.php");
$admin = new Admin();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_login'])) {
    $adminLogin = $admin->adminLogin($_POST);
    $email = $_POST['email'];
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin Login - Orbit Graphics Limited</title>
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/logoal.png">
        <link href="assets/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main class="d-flex justify-content-center align-items-center vh-100">
                    <div class="container">
                        <div class="row justify-content-center align-item-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg">
                                    <div class="card-header">
                                        <h2 class="text-center">Orbit Graphics</h2>
                                        <hr class="my-2">
                                        <h3 class="text-center font-weight-light my-2">Admin Login</h3>
                                        <?php echo isset($adminLogin) ? $adminLogin : ''; ?>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= $_SERVER['PHP_SELF']?>" method="POST" accept-charset="utf-8">
                                            <div class="form-group">
                                                <label class="small mb-1" for="email">Email</label>
                                                <input class="form-control py-4" id="email" type="email" name="email" value="<?= isset($email) ? $email : ''; ?>" placeholder="Enter email address" />
                                                <?php echo isset($admin->email) ? $admin->email : ''; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="small mb-1" for="password">Password</label>
                                                <input class="form-control py-4" id="password" name="password" type="password" placeholder="Enter password" />
                                                <?php echo isset($admin->password) ? $admin->password : ''; ?>
                                            </div>

                                            <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="small" href="admin_recover_password.php">Forgot Password?</a>
                                                <input type="submit" class="btn btn-primary" name="admin_login" value="Login">
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center p-0">
                                        <a class="p-2 d-block" href="login.php">Employee Login</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="assets/js/scripts.js"></script>
    </body>
</html>
