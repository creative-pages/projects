         <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu bg-black">
                        <div class="nav">

                            <a class="nav-link" href="index.php"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard</a
                            >

                            <a class="nav-link" href="employee_attendance.php?employee_id=<?= Session::get('employee_id'); ?>&month=<?= base64_encode(date("Y-m")); ?>"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Attendance</a
                            >
                            
                            <!-- leave -->
                            <a class="nav-link <?= $fullpath == 'leave.php' || $fullpath == 'request_leave.php' ? 'active' : 'collapsed'; ?>" href="leave.php" data-toggle="collapse" data-target="#order" aria-expanded="<?= $fullpath == 'leave.php' ? 'true' : 'false'; ?>" aria-controls="order"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Leave
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                            ></a>
                            <div class="collapse <?= $fullpath == 'leave.php' || $fullpath == 'request_leave.php' ? 'show' : ''; ?>" id="order" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="request_leave.php">Request Leave</a>
                                    <a class="nav-link" href="leave.php?pending">Pending Leave
                                        <span class="badge badge-pill badge-warning text-white ml-auto"><?= isset($total_pending_leave) ? $total_pending_leave : '0'; ?></span>
                                    </a>
                                    <a class="nav-link" href="leave.php?accepted">Accepted Leave
                                        <span class="badge badge-pill badge-info ml-auto"><?= isset($total_accepted_leave) ? $total_accepted_leave : '0'; ?></span>
                                    </a>
                                    <a class="nav-link" href="leave.php?cancelled">Cancelled Leave
                                        <span class="badge badge-pill badge-dark ml-auto"><?= isset($total_cancelled_leave) ? $total_cancelled_leave : '0'; ?></span>
                                    </a>
                                </nav>
                            </div>

                            <a class="nav-link" href="message.php"
                                >
                                <div class="sb-nav-link-icon">
                                    <i class="fas fa-envelope-open-text"></i>
                                </div>
                                Support Messages</a
                            >

                            <a class="nav-link" href="profile.php"
                                >
                                <div class="sb-nav-link-icon">
                                    <i class="fa fa-user"></i>
                                </div>
                                My Account</a
                            >
                        </div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">