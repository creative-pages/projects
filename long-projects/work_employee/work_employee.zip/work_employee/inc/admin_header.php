<?php 
ob_start();
$path = realpath(dirname(__FILE__));
include_once ($path . "/../lib/Session.php");
Session::checkSession();
if (Session::get('status') != 'admin') {
	header("Location: index.php");
}
include_once ($path . "/../classes/Department.php");
include_once ($path . "/../classes/Position.php");
include_once ($path . "/../classes/User.php");
include_once ($path . "/../classes/Leave.php");
include_once ($path . "/../classes/Contact.php");
include_once ($path . "/../config/config.php");
include_once ($path . "/../helpers/Format.php");
include_once ($path . "/../lib/Database.php");

$department = new Department();
$position = new Position();
$user = new User();
$leave = new Leave();
$contact = new Contact();

$fm = new Format();
$db = new Database();

// logout code
if (isset($_GET['logout'])) {
    Session::destroy();
}

// code for menu active
$path = explode('/', $_SERVER['PHP_SELF']);
$fullpath = end($path);

// view all department
$all_department = $department->viewAllDepartment();

// view single department
if (isset($_GET['edit_department'])) {
    $id = base64_decode($_GET['edit_department']);
    $single_department = $department->singleDepartment($id);
    $single_dept_result = $single_department->fetch_assoc();
}
// view all position
$all_position = $position->viewAllPosition();

// view single position
if (isset($_GET['edit_position'])) {
    $id = base64_decode($_GET['edit_position']);
    $single_position = $position->singlePosition($id);
    $single_pos_result = $single_position->fetch_assoc();
}

// view all user
$all_users = $user->allUsers();
if ($all_users) {
    $total_users = mysqli_num_rows($all_users);
}


// view single user
if (isset($_GET['edit_user'])) {
    $id = base64_decode($_GET['edit_user']);
    $single_user = $user->singleUser($id);
    $single_user_result = $single_user->fetch_assoc();
}

// for admin -> user pending leave
$admin_pending_leave = $leave->adminPendingLeave();
if ($admin_pending_leave) {
    $admin_total_pending_leave = mysqli_num_rows($admin_pending_leave);
}
// for admin -> user pending leave
$admin_accepted_leave = $leave->adminAcceptedLeave();
if ($admin_accepted_leave) {
    $admin_total_accepted_leave = mysqli_num_rows($admin_accepted_leave);
}
// for admin -> user pending leave
$admin_cancelled_leave = $leave->adminCancelledLeave();
if ($admin_cancelled_leave) {
    $admin_total_cancelled_leave = mysqli_num_rows($admin_cancelled_leave);
}

// code for message
$inbox = $contact->inboxAdminMessage();
if ($inbox) {
    $message_inbox_count = mysqli_num_rows($inbox);
}

$seenbox = $contact->seenboxAdminMessage();
if ($seenbox) {
    $message_seenbox_count = mysqli_num_rows($seenbox);
}

$sent = $contact->sentAdminMessage();
if ($sent) {
    $message_sent_count = mysqli_num_rows($sent);
}





?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - Orbit Graphics</title>
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/logoal.png">
        <link href="assets/css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <link href="assets/css/mystyle.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>

        <!-- js file -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="assets/js/TimeCircles.js"></script>
    </head>
    <body class="sb-nav-fixed main">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="index.php">
                <img class="w-100" src="assets/img/logo.png" alt="Logo">
            </a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button
            >
            <div class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <form action="attendance.php" method="GET">
                    <select name="employee_id" class="form-control" required="">
                        <option value="">Select Employee</option>
                    <?php 
                    if ($all_users) {
                        while ($all_user = $all_users->fetch_assoc()) {
                        ?>
                        <option value="<?= $all_user['employee_id']; ?>"><?= 'ID - ' . $all_user['employee_id'] . ' || ' . $all_user['first_name'] . ' ' . $all_user['last_name'] ?></option>
                        <?php
                        }
                    }
                    ?>
                    </select>
                   <input type="month" name="month" value="" class="form-control" required="">
                    <input type="submit" name="search_attendance" class="btn btn-info btn-sm" value="Attendance">
                </form>
            </div>
            <!-- Navbar-->
            <ul class="navbar-nav ml-auto ml-md-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Admin
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="message.php">Support Message</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="admin_change_password.php"><i class="fa fa-key"></i> Change Password</a>
                        <a class="dropdown-item" href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </li>
            </ul>
        </nav>