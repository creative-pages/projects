         <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu bg-black">
                        <div class="nav">
                            <a class="nav-link" href="dashboard.php"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard</a
                            >
                            <a class="nav-link" href="token.php"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Token</a
                            >
                            
                            <!-- department -->
                            <a class="nav-link <?= $fullpath == 'add_department.php' || $fullpath == 'manage_department.php' ? 'active' : 'collapsed'; ?>" href="#" data-toggle="collapse" data-target="#department" aria-expanded="<?= $fullpath == 'add_department.php' ? 'true' : 'false'; ?>" aria-controls="department"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Department
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                            ></a>
                            <div class="collapse <?= $fullpath == 'add_department.php' || $fullpath == 'manage_department.php' ? 'show' : ''; ?>" id="department" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="add_department.php">Add Department</a>
                                    <a class="nav-link" href="manage_department.php">Manage Department</a>
                                </nav>
                            </div>

                            <!-- position -->
                            <a class="nav-link <?= $fullpath == 'add_position.php' || $fullpath == 'manage_position.php' ? 'active' : 'collapsed'; ?>" href="#" data-toggle="collapse" data-target="#position" aria-expanded="<?= $fullpath == 'add_position.php' ? 'true' : 'false'; ?>" aria-controls="position"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Position
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                            ></a>
                            <div class="collapse <?= $fullpath == 'add_position.php' || $fullpath == 'manage_position.php' ? 'show' : ''; ?>" id="position" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="add_position.php">Add Position</a>
                                    <a class="nav-link" href="manage_position.php">Manage Position</a>
                                </nav>
                            </div>

                             <!-- employes -->
                            <a class="nav-link <?= $fullpath == 'add_employee.php' || $fullpath == 'manage_employee.php' ? 'active' : 'collapsed'; ?>" href="#" data-toggle="collapse" data-target="#employes" aria-expanded="<?= $fullpath == 'add_employee.php' ? 'true' : 'false'; ?>" aria-controls="employes"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Employes
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                            ></a>
                            <div class="collapse <?= $fullpath == 'add_employee.php' || $fullpath == 'manage_employee.php' ? 'show' : ''; ?>" id="employes" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="add_employee.php">Add Employee</a>
                                    <a class="nav-link" href="manage_employee.php">Manage Employee</a>
                                </nav>
                            </div>

                            <!-- admin_leave -->
                            <a class="nav-link <?= $fullpath == 'admin_leave.php' || $fullpath == 'request_leave.php' ? 'active' : 'collapsed'; ?>" href="admin_leave.php" data-toggle="collapse" data-target="#order" aria-expanded="<?= $fullpath == 'admin_leave.php' ? 'true' : 'false'; ?>" aria-controls="order"
                                ><div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Leave
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
                            ></a>
                            <div class="collapse <?= $fullpath == 'admin_leave.php' || $fullpath == 'request_leave.php' ? 'show' : ''; ?>" id="order" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <!-- <a class="nav-link" href="request_leave.php">Request Leave</a> -->
                                    <a class="nav-link" href="admin_leave.php?pending">Pending Leave
                                        <span class="badge badge-pill badge-warning text-white ml-auto"><?= isset($admin_total_pending_leave) ? $admin_total_pending_leave : '0'; ?></span>
                                    </a>
                                    <a class="nav-link" href="admin_leave.php?accepted">Accepted Leave
                                        <span class="badge badge-pill badge-info ml-auto"><?= isset($admin_total_accepted_leave) ? $admin_total_accepted_leave : '0'; ?></span>
                                    </a>
                                    <a class="nav-link" href="admin_leave.php?cancelled">Cancelled Leave
                                        <span class="badge badge-pill badge-dark ml-auto"><?= isset($admin_total_cancelled_leave) ? $admin_total_cancelled_leave : '0'; ?></span>
                                    </a>
                                </nav>
                            </div>

                            <a class="nav-link" href="admin_message.php"
                                ><div class="sb-nav-link-icon"><i class="fas fa-envelope-open-text"></i></div>
                                Support Messages</a
                            >

                            
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">