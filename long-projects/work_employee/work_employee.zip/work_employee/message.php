<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>
<?php 

// insert message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
	$message = $contact->insertMessage($_POST);
	if ($message) {
	?>
	<script type="text/javascript">
		alert('Message sent Succesfullly.');
	</script>
	<?php
	header("Location: message.php?sent");
	}
}

?>
<main>
	<div class="container-fluid pt-3">
		
		<a class="btn btn-info btn-sm" href="message.php"><i class="fas fa-sync-alt"></i></a>
		<a class="btn btn-info btn-sm" href="message.php">Inbox <span class="badge badge-light"><?= isset($message_inbox_count) ? $message_inbox_count : ''; ?></span></a>
		<a class="btn btn-primary btn-sm" href="message.php?seen">Seenbox</a>
		<a class="btn btn-success btn-sm" href="message.php?sent">Sent</a>
		<a class="btn btn-info btn-sm" href="message.php?compose">Compose New</a>

		<div class="bg-light mt-2">
			<?php
			if (isset($_GET['sent'])) {
			?>
			<div class="card mb-4">
				<div class="card-header">
					<span>Displaying Sent Messages</span>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Subject</th>
									<th>Message</th>
									<th>Date</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									if ($sent) {
								while ($all_sent = mysqli_fetch_assoc($sent)) {
								?>
								<tr>
									<td><?= $all_sent['subject']; ?></td>
									<td><?= $all_sent['description']; ?></td>
									<td><?= $fm->dateFormat($all_sent['date_time']); ?></td>
									<td>
										<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#view_message-<?= $all_sent['id']; ?>">View</button>
									</td>
								</tr>
								<?php
								}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<?php
			} elseif (isset($_GET['seen'])) {
			?>
			<div class="card mb-4">
				<div class="card-header">
					<span>Displaying Seen Messages</span>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Subject</th>
									<th>Message</th>
									<th>Date</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									if ($seenbox) {
								while ($all_seen = mysqli_fetch_assoc($seenbox)) {
								?>
								<tr>
									<td><?= $all_seen['subject']; ?></td>
									<td><?= $all_seen['description']; ?></td>
									<td><?= $fm->dateFormat($all_seen['date_time']); ?></td>
									<td>
										<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#view_message-<?= $all_seen['id']; ?>">View</button>
									</td>
								</tr>
								<?php
								}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<?php
			} elseif (isset($_GET['compose'])) {
			?>
			<div class="container py-3">
				<div class="row">
					<div class="col-sm-6">
						<div class="card">
							<div class="card-header">
								<span>Support Request Form</span>
								<span class="float-right">
									<a class="text-info txt_all" href="message.php?sent"><i class="fa fa-angle-double-right text-black"></i> All Messages</a>
								</span>
							</div>
							<div class="card-body">
								<form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
									<div class="row">
										<div class="col">
											<input type="text" class="form-control" name="subject" placeholder="Subject" required="">
										</div><!--
										<div class="col">
												<select class="form-control" name="query">
														<option value="">Select Query</option>
														<option value=""></option>
														<option value=""></option>
												</select>
										</div> -->
									</div>
									<textarea name="description" class="form-control mt-3" rows="5" required=""></textarea>
									<button type="submit" name="message" class="btn btn-info float-right mt-3">SEND MESSAGE</button>
								</form>
								<?php
									if (isset($message)) {
										echo '<br>';
										echo $message;
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
			} else {
			?>
			<div class="card mb-4">
				<div class="card-header">
					<span>Displaying Inbox Messages</span>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Subject</th>
									<th>Message</th>
									<th>Date</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									if ($inbox) {
								while ($all_inbox = mysqli_fetch_assoc($inbox)) {
								?>
								<tr>
									<td><?= $all_inbox['subject']; ?></td>
									<td><?= $all_inbox['description']; ?></td>
									<td><?= $fm->dateFormat($all_inbox['date_time']); ?></td>
									<td>
										<a class="btn btn-info btn-sm" href="message_view.php?message_id=<?= $all_inbox['id']; ?>">View</a>
									</td>
								</tr>
								<?php
								}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<?php
			}
			?>
		</div>
	</div>
</main>



<?php 
$all_message = $contact->allMessage();
if ($all_message) {
	while ($all = mysqli_fetch_assoc($all_message)) {
	?>
	<!-- Modal -->
	<div class="modal fade" id="view_message-<?= $all['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Message ID - <?= $all['id']; ?></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <table class="table table-bordered table-striped">
	        	<tbody>
	        		<tr>
	        			<td>Date</td>
	        			<td><?= $fm->dateFormat($all['date_time']); ?></td>
	        		</tr>
	        		<tr>
	        			<td>Subject</td>
	        			<td><?= $all['subject']; ?></td>
	        		</tr>
	        		<tr>
	        			<td>Message</td>
	        			<td><?= $all['description']; ?></td>
	        		</tr>
	        	</tbody>
	        </table>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
	    </div>
	  </div>
	</div>
	<?php
	}
}

?>
<?php require_once "inc/footer.php"; ?>