<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php 

$single_token = $user->singleToken();
if ($single_token) {
	$single_token_result = $single_token->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_token'])) {
	$update_token = $user->updateToken($_POST);
}

?>
<main>
	<div class="container-fluid pt-3">
		<h3 class="mb-1 text-muted">Today is <span class="text-primary"><?= date('l'); ?></span></h3>
		<small class="text-muted"><?= date('d-F-Y') . ' || ' . date('h-i-A'); ?></small>
		<br>
		<br>
		<div class="row">
			<div class="col-sm-6 offset-sm-3">
				<div class="card card-1">
					<div class="card-heading"></div>
					<div class="card-body">
						<h4 class="text-center text-muted">Token is: <span class="text-primary"><?= $single_token_result['token']; ?></span></h4>
						<hr>
						<form action="<?= $_SERVER["PHP_SELF"]; ?>" method="POST">
							<div class="form-group row mt-3">
							    <label for="token" class="col-sm-3 col-form-label">Token</label>
							    <div class="col-sm-9">
							      <input type="text" class="form-control" placeholder="Enter new token" id="token" name="token" required="">
							    </div>
							</div>
							<div class="my-3 text-right">
								<input class="btn btn-primary btn-sm" type="submit" name="update_token" value="Update">
							</div>
						</form>
						<?php echo isset($update_token) ? $update_token : ''; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>