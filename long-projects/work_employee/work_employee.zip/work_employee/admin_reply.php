<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php 

if (isset($_GET['reply_message'])) {
	$id = $_GET['reply_message'];
	$view_message = $contact->viewMessage($id);
	if ($view_message) {
		$single_message = mysqli_fetch_assoc($view_message);
	}
}

// insert message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
	$message = $contact->insertMessage($_POST);
}

?>

<main>
	<div class="container-fluid pt-3">
		<a class="btn btn-success btn-sm" href="admin_message.php?sent">Sent</a>
		<a class="btn btn-primary btn-sm" href="admin_message.php">Inbox</a>
		<div class="bg-light mt-2">
			<div class="container py-3">
				<div class="row">
					<div class="col-sm-6">
						<div class="card">
							<div class="card-header">
								<span>Support Request Form</span>
								<span class="float-right">User ID: <?= isset($single_message['user_id']) ? $single_message['user_id'] : ''; ?></span>
							</div>
							<div class="card-body">
								<form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
									<div class="row">
										<div class="col">
											<input type="hidden" class="form-control" name="user_id" value="<?= $single_message['user_id']; ?>" required="">
											<input type="hidden" name="subject" class="form-control" value="<?= $single_message['subject']; ?>" required="" readonly="">
											
											<?php 
											if (Session::get('status') == '4') {
											?>
											<input type="text" class="form-control mb-3" name="name" value="To: <?= isset($single_message['fullname']) ? $single_message['fullname'] : ''; ?>" readonly="">
											<?php
											}
											?>
											<input type="text" class="form-control" value="Subject: <?= isset($single_message['subject']) ? $single_message['subject'] : ''; ?>" required="" readonly="">
										</div><!--
										<div class="col">
												<select class="form-control" name="query">
														<option value="">Select Query</option>
														<option value=""></option>
														<option value=""></option>
												</select>
										</div> -->
									</div>
									<textarea name="description" class="form-control mt-3" rows="5" required=""></textarea>
									<button type="submit" name="message" class="btn btn-info float-right mt-3">SEND MESSAGE</button>
								</form>
								<?php
									if (isset($message)) {
										echo '<br>';
										echo $message;
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>