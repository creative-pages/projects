<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<main>
	<div class="container-fluid pt-3">
		<h3 class="mb-1 text-muted">Dashboard</h3>
		<small class="text-muted">Welcome back Admin</small>
		<br>
		<br>
		<div class="row">
			<div class="col-sm-4">
				<a href="manage_employee.php"  class="text-decoration-none">
					<div class="card border-0 bg-success text-white">
						<h3 class="card-header py-4 text-center">All Employee</h3>
					</div>
				</a>
				<?= isset($check_in) ? $check_in : ''; ?>
			</div>
			<div class="col-sm-4">
				<a href="admin_leave.php?pending"  class="text-decoration-none">
					<div class="card border-0 bg-warning text-white">
						<h3 class="card-header py-4 text-center">Leave Request <span class="badge badge-light"><?= isset($admin_total_pending_leave) ? $admin_total_pending_leave : '0'; ?></span></h3>
					</div>
				</a>
				<?= isset($check_out) ? $check_out : ''; ?>
			</div>
			<div class="col-sm-4">
				<a href="admin_message.php" class="text-decoration-none">
					<div class="card border-0 bg-primary text-white mb-4">
						<h3 class="card-header py-4 text-center">Inbox <span class="badge badge-light"><?= isset($message_inbox_count) ? $message_inbox_count : ''; ?></span></h3>
					</div>
				</a>
			</div>
			
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="card mb-4">
					<div class="card-header">
						<span>All Employee List: </span>
						<span class="float-right text-muted">Total Employee: <?= isset($total_users) ? $total_users : '0'; ?></span>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>EM-ID</th>
										<th>Name</th>
										<th>Photo</th>
										<th>Attendance</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$all_users = $user->allUsers();
										if ($all_users) {
									while ($all_user = $all_users->fetch_assoc()) {
									?>
									<tr>
										<td><?= $all_user['employee_id']; ?></td>
										<td><?= $all_user['first_name'] . ' ' . $all_user['last_name']; ?></td>
										<td style="padding: 6px;">
											<img width="80" height="50" src="uploadFiles/<?= $all_user['photo']; ?>" alt="">
										</td>
										<td>
											<a href="attendance.php?employee_id=<?= $all_user['employee_id']; ?>&id=<?= base64_encode($all_user['id']); ?>" class="btn btn-info btn-sm">View</a>
										</td>
									</tr>
									<?php
									}
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="card mb-4">
					<div class="card-header">
						<span>All Pending Leave: </span>
						<span class="float-right">
							<a href="admin_leave.php?pending" class="badge badge-pill badge-warning text-white"><?= isset($admin_total_pending_leave) ? $admin_total_pending_leave : '0'; ?> Pending</a>
							<a href="admin_leave.php?accepted" class="badge badge-pill badge-info"><?= isset($admin_total_accepted_leave) ? $admin_total_accepted_leave : '0'; ?> Accepted</a>
							<a href="admin_leave.php?cancelled" class="badge badge-pill badge-dark"><?= isset($admin_total_cancelled_leave) ? $admin_total_cancelled_leave : '0'; ?> Cancelled</a>
						</span>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-striped table-hover" id="dataTable_leave" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>ID</th>
										<th>Name</th>
										<th>Day's</th>
										<th>Status</th>
										<th>Date</th>
									</tr>
								</thead>
								<tbody>
									<?php
										
								if ($admin_pending_leave) {
									while ($pending = mysqli_fetch_assoc($admin_pending_leave)) {
									?>
									<tr>
										<td><?= $pending['employee_id']; ?></td>
										<td><?= $pending['employee_name']; ?></td>
										<td><?= $pending['days']; ?></td>
										<td>
											<a class="btn btn-success btn-sm" href="admin_leave.php?accept_leave=<?= base64_encode($pending['id']); ?>" onclick="return confirm('Are you sure to accept?');">Accept</a>
											<a class="btn btn-dark btn-sm" href="admin_leave.php?cancel_leave=<?= base64_encode($pending['id']); ?>" onclick="return confirm('Are you sure to cancel?');">Cancel</a>
										</td>
										<td><?= $fm->dateFormat($pending['create_date']); ?></td>
									</tr>
									<?php
									}
								}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<br>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>