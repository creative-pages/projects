<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>

<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_department'])) {
	$update_dept = $department->updateDepartment($_POST);
}

?>
<main>
	<div class="container-fluid pt-3">
		<br>
		<br>
		<div class="row">
			<div class="col-sm-6 offset-sm-3">
				<div class="card card-1">
					<div class="card-heading"></div>
					<div class="card-body">
						<h2 class="text-center text-muted">Update Department</h2>
						<hr>
						<form action="<?= $_SERVER["PHP_SELF"]; ?>" method="POST">
							<div class="form-group row mt-3">
							    <label for="dept" class="col-sm-3 col-form-label">Department</label>
							    <div class="col-sm-9">
							    	<input type="hidden" name="id" value="<?= $single_dept_result['id']; ?>">
							      <input type="text" class="form-control" value="<?= isset($single_dept_result['dept']) ? $single_dept_result['dept'] : ''; ?>" placeholder="Enter department name" id="dept" name="dept" required="">
							    </div>
							</div>
							<div class="my-3 text-right">
								<input class="btn btn-primary btn-sm" type="submit" name="update_department" value="Submit">
							</div>
						</form>
						<?php echo isset($update_dept) ? $update_dept : ''; ?>
					</div>
				</div>
			</div>
		</div>
		<br>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>