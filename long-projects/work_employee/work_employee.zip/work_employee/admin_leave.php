<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>

<?php 

if (isset($_GET['accept_leave'])) {
	$id = base64_decode($_GET['accept_leave']);
	$leave_status = $leave->acceptLeave($id);
	if ($leave_status) {
		header("Location: admin_leave.php?accepted");
	}
} elseif (isset($_GET['cancel_leave'])) {
	$id = base64_decode($_GET['cancel_leave']);
	$leave_status = $leave->cancelLeave($id);
	if ($leave_status) {
		header("Location: admin_leave.php?cancelled");
	}
} elseif (isset($_GET['delete_leave'])) {
	$id = base64_decode($_GET['delete_leave']);
	$leave_status = $leave->deleteLeave($id);
	if ($leave_status) {
		header("Location: admin_leave.php?cancelled");
	}
}

?>

<main class="bg-light">
	<div class="container-fluid pt-3">
		<div class="card mb-4">
			<div class="card-header">
				<span>
				<?php 
				if (isset($_GET['pending'])) {
					echo '<b>List of Pending Leave</b>';
				} elseif (isset($_GET['accepted'])) {
					echo '<b>List of Accepted Leave</b>';
				} elseif (isset($_GET['cancelled'])) {
					echo '<b>List of Cancelled Leave</b>';
				}
				?>
				</span>
				<span class="float-right">
					<a href="admin_leave.php?pending" class="badge badge-pill badge-warning text-white"><?= isset($admin_total_pending_leave) ? $admin_total_pending_leave : '0'; ?> Pending</a>
					<a href="admin_leave.php?accepted" class="badge badge-pill badge-info"><?= isset($admin_total_accepted_leave) ? $admin_total_accepted_leave : '0'; ?> Accepted</a>
					<a href="admin_leave.php?cancelled" class="badge badge-pill badge-dark"><?= isset($admin_total_cancelled_leave) ? $admin_total_cancelled_leave : '0'; ?> Cancelled</a>
				</span>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>From Date</th>
								<th>To Date</th>
								<th>Day's</th>
								<th>Reason</th>
								<th>Description</th>
								<th>Status</th>
								<th>Date</th>
							</tr>
						</thead>
						<tbody>
				<?php

		 			if (isset($_GET['pending'])) {
						if ($admin_pending_leave) {
							while ($pending = mysqli_fetch_assoc($admin_pending_leave)) {
							?>
							<tr>
								<td><?= $pending['employee_id']; ?></td>
								<td><?= $pending['employee_name']; ?></td>
								<td><?= $pending['from_date']; ?></td>
								<td><?= $pending['to_date']; ?></td>
								<td><?= $pending['days']; ?></td>
								<td><?= $pending['reason']; ?></td>
								<td><?= $pending['description']; ?></td>
								<td>
									<a class="btn btn-success btn-sm" href="admin_leave.php?accept_leave=<?= base64_encode($pending['id']); ?>" onclick="return confirm('Are you sure to accept?');">Accept</a>
									<a class="btn btn-dark btn-sm" href="admin_leave.php?cancel_leave=<?= base64_encode($pending['id']); ?>" onclick="return confirm('Are you sure to cancel?');">Cancel</a>
								</td>
								<td><?= $fm->dateFormat($pending['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					} elseif (isset($_GET['accepted'])) {
						if ($admin_accepted_leave) {
							while ($accepted = mysqli_fetch_assoc($admin_accepted_leave)) {
							?>
							<tr>
								<td><?= $accepted['employee_id']; ?></td>
								<td><?= $accepted['employee_name']; ?></td>
								<td><?= $accepted['from_date']; ?></td>
								<td><?= $accepted['to_date']; ?></td>
								<td><?= $accepted['days']; ?></td>
								<td><?= $accepted['reason']; ?></td>
								<td><?= $accepted['description']; ?></td>
								<td>
									<a class="btn btn-danger btn-sm" href="admin_leave.php?delete_leave=<?= base64_encode($accepted['id']); ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
								</td>
								<td><?= $fm->dateFormat($accepted['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					} elseif (isset($_GET['cancelled'])) {
						if ($admin_cancelled_leave) {
							while ($cancelled = mysqli_fetch_assoc($admin_cancelled_leave)) {
							?>
							<tr>
								<td><?= $cancelled['employee_id']; ?></td>
								<td><?= $cancelled['employee_name']; ?></td>
								<td><?= $cancelled['from_date']; ?></td>
								<td><?= $cancelled['to_date']; ?></td>
								<td><?= $cancelled['days']; ?></td>
								<td><?= $cancelled['reason']; ?></td>
								<td><?= $cancelled['description']; ?></td>
								<td>
									<a class="btn btn-success btn-sm" href="admin_leave.php?accept_leave=<?= base64_encode($cancelled['id']); ?>" onclick="return confirm('Are you sure to accept?');">Accept</a>
									<a class="btn btn-danger btn-sm" href="admin_leave.php?delete_leave=<?= base64_encode($cancelled['id']); ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
								</td>
								<td><?= $fm->dateFormat($cancelled['create_date']); ?></td>
							</tr>
							<?php
							}
						}
					}

				?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>