<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php 

if (isset($_GET['delete_id'])) {
	$id = base64_decode($_GET['delete_id']);
	$delete_result = $department->deleteDepartment($id);
	if ($delete_result) {
		header("Location: manage_department.php");
	}
}

?>
<main class="bg-light">
	<div class="container-fluid pt-3">
		<div class="card mb-4">
			<div class="card-header">
				<span>
				Manage Department
				</span>
				<span class="float-right">
					<a href="add_department.php" class="btn btn-primary btn-sm">Add Department</a>
				</span>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>Serial No.</th>
								<th>Department</th>
								<th>Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
					<?php 
						if ($all_department) {
							$sl = 1;
							while ($departments = $all_department->fetch_assoc()) {
							?>
							<tr>
								<td><?= $sl; ?></td>
								<td><?= $departments['dept']; ?></td>
								<td><?= $fm->dateFormat($departments['create_time']); ?></td>
								<td>
									<a class="btn btn-warning btn-sm" href="update_department.php?edit_department=<?= base64_encode($departments['id']); ?>">Edit</a>
									<a class="btn btn-danger btn-sm" href="manage_department.php?delete_id=<?= base64_encode($departments['id']); ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
								</td>
							</tr>
							<?php
							$sl++;
							}
						}
					?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>

<?php require_once "inc/admin_footer.php"; ?>