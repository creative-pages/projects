<?php require_once "inc/admin_header.php"; ?>
<?php require_once "inc/admin_sidebar.php"; ?>
<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_employee'])) {
	$add_user = $user->addUser($_POST);
}

?>
<main>
	<div class="container-fluid pt-3">
		<div class="row">
			<div class="col-sm-10 offset-sm-1 col-md-6 offset-md-3">
				<div class="card card-1">
					<div class="card-heading"></div>
					<div class="card-body">
						<?php echo isset($add_user) ? $add_user : ''; ?>
						<h2 class="text-center text-muted">Add Employee</h2>
						<hr>
						<form action="<?= $_SERVER["PHP_SELF"]; ?>" method="POST" enctype="multipart/form-data">
							
							<div class="form-group mb-0">
								<input class="form-control mt-3" type="text" placeholder="Employee ID" name="employee_id" required="required">
								<?php echo isset($user->employee_id) ? $user->employee_id : ''; ?>
							</div>
							<div class="form-row mt-3">
								<div class="col-6">
									<div class="form-group mb-0">
										<input class="form-control" type="text" placeholder="First Name" name="first_name" required="required">
									</div>
								</div>
								<div class="col-6">
									<div class="form-group mb-0">
										<input class="form-control" type="text" placeholder="Last Name" name="last_name" required="required">
									</div>
								</div>
							</div>
							<div class="form-group mb-0 mt-3">
								<input class="form-control mt-3" type="email" placeholder="Email" name="email" required="required">
								<?php echo isset($user->email) ? $user->email : ''; ?>
							</div>
							<div class="form-group mb-0 mt-3">
								<select class="form-control" name="dept" required="">
									<option value="">Select Department</option>
								  	<?php 
									if ($all_department) {
										while ($departments = $all_department->fetch_assoc()) {
										?>
										<option value="<?= $departments['dept']; ?>"><?= $departments['dept']; ?></option>
										<?php
										}
									}
								?>
								</select>
							</div>
							<div class="form-group mb-0 mt-3">
								<select class="form-control" name="pos" required="">
									<option value="">Select Position</option>
								  	<?php 
									if ($all_position) {
										while ($positions = $all_position->fetch_assoc()) {
										?>
										<option value="<?= $positions['pos']; ?>"><?= $positions['pos']; ?></option>
										<?php
										}
									}
								?>
								</select>
							</div>
							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="number" min="0" placeholder="Salary" name="salary" required="">
							</div>
							<div class="form-group mb-0 mt-3">
								<label for="hire_date">Date of Hire</label>
								<input class="form-control" type="date" placeholder="BIRTHDATE" id="hire_date" name="hire_date" required="required">
							</div>
							<hr>
							<div class="form-row mt-3">
								<div class="col-6">
									<div class="form-group mb-0">
										<label for="birthday">BIRTHDATE</label>
										<input class="form-control" type="date" placeholder="BIRTHDATE" id="birthday" name="birthday" required="required">
									</div>
								</div>
								<div class="col-6">
									<div class="form-group mb-0">
										<label for="gender">GENDER</label>
										<select id="gender" name="gender" class="form-control" required="">
											<option value="">Select Gender</option>
											<option value="Male">Male</option>
											<option value="Female">Female</option>
											<option value="Other">Other</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="form-group mb-0 mt-3">
								<select name="marital_status" class="form-control" required="">
									<option value="">Marital Status</option>
									<option value="Single">Single</option>
									<option value="Married">Married</option>
									<option value="Widowed">Widowed</option>
								</select>
							</div>

							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="text" placeholder="Contact Number" name="phone" required="required" pattern="01[3|4|5|6|7|8|9][0-9]{8}">
								<?php echo isset($user->phone) ? $user->phone : ''; ?>
							</div>
							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="number" min="0" placeholder="NID" name="nid" required="required">
							</div>
							
							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="text" placeholder="Address" name="address" required="required">
							</div>
							
							<div class="form-group mb-0 mt-3">
								<input class="form-control" type="file" placeholder="file" name="photo" required="">
							</div>
							<div class="mt-3 text-right">
								<input class="btn btn-primary btn-sm" type="submit" name="add_employee" value="Submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<br>
	</div>
</main>
<?php require_once "inc/admin_footer.php"; ?>