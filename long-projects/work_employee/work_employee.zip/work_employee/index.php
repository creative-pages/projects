<?php require_once "inc/header.php"; ?>
<?php require_once "inc/sidebar.php"; ?>

<?php 
// check in & check out
if (isset($_GET['check_in'])) {
	$check_in = $user->checkIn();
	if ($check_in) {
		header("Location: index.php");
	}
} elseif (isset($_GET['check_out'])) {
	$check_out = $user->checkOut();
	if ($check_out) {
		header("Location: index.php");
	}
}

// insert message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
	$message = $contact->insertMessage($_POST);
}


// today's check in & check out
$check_details = $user->todayCheckInOut();
if ($check_details != NUll) {
	$check_details_result = mysqli_fetch_assoc($check_details);
}


?>


<main>
	<div class="container-fluid pt-3">
		<h3 class="mb-1 text-muted">Dashboard</h3>
		<small class="text-muted">Welcome back <a href="profile.php" class="text-info"><?= $user_info_result['first_name'] . ' ' . $user_info_result['last_name']; ?></a>!</small>
		<br>
		<br>
		<div class="row">
			
				<?php 
				if ($check_details == NUll) {
				?>
				<div class="col-xl-3 col-md-6">
					<a href="index.php?check_in"  class="text-decoration-none" onclick="return confirm('Are you sure to Check In?');">
						<div class="card border-0 bg-success text-white">
							<h3 class="card-header py-4 text-center">Check In</h3>
						</div>
					</a>
					<?= isset($check_in) ? $check_in : ''; ?>
				</div>
				
				<?php
				}
				?>

				<?php 
				if (isset($check_details_result['time']) && $check_details_result['time'] == '') {
				?>
				<div class="col-xl-3 col-md-6">
					<a href="index.php?check_out"  class="text-decoration-none" onclick="return confirm('Are you sure to Check Out?');">
						<div class="card border-0 bg-warning text-white">
							<h3 class="card-header py-4 text-center">Check Out</h3>
						</div>
					</a>
					<?= isset($check_out) ? $check_out : ''; ?>
				</div>
				<?php
				}
				?>
			
			<div class="col-xl-3 col-md-6">
				<a href="message.php" class="text-decoration-none">
					<div class="card border-0 bg-primary text-white mb-4">
					<h3 class="card-header py-4 text-center">Inbox <span class="badge badge-light"><?= isset($message_inbox_count) ? $message_inbox_count : ''; ?></span></h3>
				</div>
				</a>
			</div>
			
		</div>
		<div class="row">
			<div class="col-sm-6">
				<table class="table table-bordered table-striped">
					<tr>
						<th>Date</th>
						<th>Check In Time</th>
						<th>Check Out Time</th>
						<th>Total Work Hour</th>
					</tr>
					<tr>
						<td><?= isset($check_details_result['date']) ? $fm->dateFormat($check_details_result['date']) : ''; ?></td>
						<td><?= isset($check_details_result['check_in']) ? date("h:ia", strtotime($check_details_result['check_in']. ' + 4 hours')) : ''; ?></td>
						<td><?= isset($check_details_result['check_out']) && $check_details_result['check_out'] != '0000-00-00 00:00:00' ? date("h:ia", strtotime($check_details_result['check_out']. ' + 4 hours')) : ''; ?></td>
						<td><?= isset($check_details_result['time']) ? $check_details_result['time'] : ''; ?></td>
					</tr>
				</table>
			</div>
			<div class="col-sm-6">
				<div class="card">
					<div class="card-header">
						<span>Support Request Form</span>
						<span class="float-right">
							<a class="text-info txt_all" href="message.php"><i class="fa fa-angle-double-right text-black"></i> All Messages</a>
						</span>
					</div>
					<div class="card-body">
						<form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
							<div class="row">
								<div class="col">
									<input type="text" class="form-control" name="subject" placeholder="Subject" required="">
								</div>
							</div>
							<textarea name="description" class="form-control mt-3" rows="5" required=""></textarea>
							<button type="submit" name="message" class="btn btn-info float-right mt-3">SEND MESSAGE</button>
						</form>
						<?php 
							if (isset($message)) {
								echo '<br>';
								echo $message;
							}
						?>
					</div>
				</div>
				<br>
			</div>
		</div>
	</div>
</main>
<?php require_once "inc/footer.php"; ?>